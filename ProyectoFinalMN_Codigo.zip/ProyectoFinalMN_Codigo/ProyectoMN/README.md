# Proyecto Final — Métodos Numéricos con Python
## Universidad Mariano Gálvez — Curso 021

### Instalación
```bash
pip install -r requirements.txt
python main.py
```

### Estructura
```
ProyectoMN/
├── main.py              # Ventana principal (QMainWindow + QTabWidget)
├── metodos.py           # Todos los métodos numéricos implementados
├── themes.py            # Sistema de temas (Oscuro, Claro, Azul Marino)
├── utils.py             # Evaluador seguro de expresiones matemáticas
├── requirements.txt
└── tabs/
    ├── tab_raices.py        # Módulo 1: Bisección, Newton, Secante, etc.
    ├── tab_interpolacion.py # Módulo 2: Lagrange, Newton DD, Spline, MC
    ├── tab_sistemas.py      # Módulo 3: Gauss, LU, Jacobi, Gauss-Seidel
    ├── tab_integracion.py   # Módulo 4: Trapecio, Simpson, Gauss-Legendre
    └── tab_edo.py           # Módulo 5: Euler, Heun, RK4, RK45, solve_ivp
```

### Módulos
- **Módulo 1** — Raíces: Bisección, Newton-Raphson, Secante, Regula Falsi, Punto Fijo, SciPy brentq
- **Módulo 2** — Interpolación: Lagrange, Newton DD, Spline Cúbico, Mínimos Cuadrados
- **Módulo 3** — Sistemas: Gauss, Gauss-Jordan, LU, Jacobi, Gauss-Seidel
- **Módulo 4** — Integración: Trapecio, Simpson 1/3, 3/8, Gauss-Legendre, quad; Derivadas: Adelante, Atrás, Centrada, Segunda, Orden 4
- **Módulo 5** — EDO: Euler, Euler Mejorado, RK4, RK45 Adaptativo, solve_ivp

### Tecnologías
Python 3.x · PyQt6 · NumPy · SciPy · Matplotlib · SymPy
