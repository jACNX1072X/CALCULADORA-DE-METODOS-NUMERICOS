"""
PROYECTO J&R — Sistema de Temas
Paletas de colores y helpers de estilo para PyQt6 + Matplotlib.
"""

THEMES = {
    "oscuro": {
        "bg_primary":     "#0f1117",
        "bg_secondary":   "#1a1d2e",
        "bg_card":        "#1e2235",
        "bg_sidebar":     "#13151f",
        "accent":         "#6c63ff",
        "accent2":        "#ff6584",
        "accent3":        "#43e97b",
        "text_primary":   "#e8eaf6",
        "text_secondary": "#9ea7c4",
        "border":         "#2a2f4a",
        "hover":          "#252840",
        "plot_bg":        "#1a1d2e",
        "plot_fg":        "#e8eaf6",
        "plot_grid":      "#2a2f4a",
        "mpl_style":      "dark_background",
        "label":          "🌑 Oscuro",
    },
    "claro": {
        "bg_primary":     "#f4f6fb",
        "bg_secondary":   "#ffffff",
        "bg_card":        "#ffffff",
        "bg_sidebar":     "#e8ecf5",
        "accent":         "#5c54e8",
        "accent2":        "#e8335a",
        "accent3":        "#2ecc71",
        "text_primary":   "#1a1d2e",
        "text_secondary": "#5a6078",
        "border":         "#d0d5e8",
        "hover":          "#eceffe",
        "plot_bg":        "#ffffff",
        "plot_fg":        "#1a1d2e",
        "plot_grid":      "#e0e4f0",
        "mpl_style":      "seaborn-v0_8-whitegrid",
        "label":          "☀️ Claro",
    },
    "azul_marino": {
        "bg_primary":     "#05070f",
        "bg_secondary":   "#0a0e1f",
        "bg_card":        "#0d1228",
        "bg_sidebar":     "#070919",
        "accent":         "#00d4ff",
        "accent2":        "#ff6b6b",
        "accent3":        "#00ff9d",
        "text_primary":   "#c8e6ff",
        "text_secondary": "#6a8caf",
        "border":         "#1a2540",
        "hover":          "#111830",
        "plot_bg":        "#0a0e1f",
        "plot_fg":        "#c8e6ff",
        "plot_grid":      "#1a2540",
        "mpl_style":      "dark_background",
        "label":          "🌊 Azul Marino",
    },
}

CURRENT_THEME = "oscuro"


def get_theme() -> dict:
    return THEMES[CURRENT_THEME]


def set_theme(name: str):
    global CURRENT_THEME
    if name in THEMES:
        CURRENT_THEME = name


def build_stylesheet(t: dict) -> str:
    return f"""
    QMainWindow, QWidget {{
        background-color: {t['bg_primary']};
        color: {t['text_primary']};
        font-family: 'Segoe UI', 'Arial', sans-serif;
        font-size: 13px;
    }}
    QTabWidget::pane {{
        border: 1px solid {t['border']};
        background: {t['bg_secondary']};
        border-radius: 6px;
    }}
    QTabBar::tab {{
        background: {t['bg_card']};
        color: {t['text_secondary']};
        padding: 8px 18px;
        border: 1px solid {t['border']};
        border-bottom: none;
        border-radius: 4px 4px 0 0;
        margin-right: 2px;
    }}
    QTabBar::tab:selected {{
        background: {t['accent']};
        color: #ffffff;
        font-weight: bold;
    }}
    QTabBar::tab:hover {{
        background: {t['hover']};
        color: {t['text_primary']};
    }}
    QGroupBox {{
        border: 1px solid {t['border']};
        border-radius: 6px;
        margin-top: 10px;
        padding: 8px;
        color: {t['text_primary']};
        font-weight: bold;
    }}
    QGroupBox::title {{
        subcontrol-origin: margin;
        left: 10px;
        color: {t['accent']};
    }}
    QLineEdit, QTextEdit, QDoubleSpinBox, QSpinBox, QComboBox {{
        background: {t['bg_card']};
        color: {t['text_primary']};
        border: 1px solid {t['border']};
        border-radius: 4px;
        padding: 4px 8px;
        selection-background-color: {t['accent']};
    }}
    QLineEdit:focus, QTextEdit:focus {{
        border: 1px solid {t['accent']};
    }}
    QPushButton {{
        background: {t['accent']};
        color: #ffffff;
        border: none;
        border-radius: 5px;
        padding: 7px 16px;
        font-weight: bold;
    }}
    QPushButton:hover {{
        background: {t['accent2']};
    }}
    QPushButton:pressed {{
        background: {t['bg_card']};
        color: {t['accent']};
        border: 1px solid {t['accent']};
    }}
    QPushButton:disabled {{
        background: {t['border']};
        color: {t['text_secondary']};
    }}
    QTableWidget {{
        background: {t['bg_card']};
        color: {t['text_primary']};
        gridline-color: {t['border']};
        border: 1px solid {t['border']};
        border-radius: 4px;
    }}
    QHeaderView::section {{
        background: {t['bg_secondary']};
        color: {t['accent']};
        border: 1px solid {t['border']};
        padding: 4px;
        font-weight: bold;
    }}
    QScrollBar:vertical {{
        background: {t['bg_secondary']};
        width: 8px;
        border-radius: 4px;
    }}
    QScrollBar::handle:vertical {{
        background: {t['border']};
        border-radius: 4px;
        min-height: 20px;
    }}
    QScrollBar::handle:vertical:hover {{
        background: {t['accent']};
    }}
    QSplitter::handle {{
        background: {t['border']};
    }}
    QStatusBar {{
        background: {t['bg_sidebar']};
        color: {t['text_secondary']};
        border-top: 1px solid {t['border']};
    }}
    QMenuBar {{
        background: {t['bg_sidebar']};
        color: {t['text_primary']};
        border-bottom: 1px solid {t['border']};
    }}
    QMenuBar::item:selected {{
        background: {t['hover']};
    }}
    QMenu {{
        background: {t['bg_card']};
        color: {t['text_primary']};
        border: 1px solid {t['border']};
    }}
    QMenu::item:selected {{
        background: {t['accent']};
        color: #ffffff;
    }}
    QCheckBox {{
        color: {t['text_primary']};
        spacing: 6px;
    }}
    QCheckBox::indicator {{
        width: 14px; height: 14px;
        border: 1px solid {t['border']};
        border-radius: 3px;
        background: {t['bg_card']};
    }}
    QCheckBox::indicator:checked {{
        background: {t['accent']};
        border-color: {t['accent']};
    }}
    QLabel {{
        color: {t['text_primary']};
    }}
    QProgressBar {{
        background: {t['bg_card']};
        border: 1px solid {t['border']};
        border-radius: 4px;
        text-align: center;
        color: {t['text_primary']};
    }}
    QProgressBar::chunk {{
        background: {t['accent']};
        border-radius: 3px;
    }}
    """
