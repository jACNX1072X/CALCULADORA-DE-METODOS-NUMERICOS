"""
PROYECTO FINAL — Métodos Numéricos
Universidad Mariano Gálvez
Curso: 021 — Métodos Numéricos con Python

Punto de entrada principal de la aplicación.
Uso:
    python main.py
"""

import sys
import os
import datetime

# Asegurar que el directorio del proyecto esté en el path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QTabWidget,
    QVBoxLayout, QHBoxLayout, QPushButton, QLabel,
    QComboBox, QStatusBar, QMenuBar, QMenu,
    QDockWidget, QListWidget, QListWidgetItem, QSizePolicy,
    QMessageBox,
)
from PyQt6.QtCore import Qt, QSize
from PyQt6.QtGui import QFont, QAction

import themes as TM
from tabs.tab_raices import TabRaices
from tabs.tab_interpolacion import TabInterpolacion
from tabs.tab_sistemas import TabSistemas
from tabs.tab_integracion import TabIntegracion
from tabs.tab_edo import TabEDO


class VentanaPrincipal(QMainWindow):
    """
    Ventana principal de la aplicación de Métodos Numéricos.
    Integra los cinco módulos como pestañas dentro de un QTabWidget.
    Incluye sistema de temas, historial de cálculos y barra de estado.
    """

    def __init__(self):
        super().__init__()
        self.setWindowTitle("Métodos Numéricos — Proyecto Final")
        self.setMinimumSize(1100, 720)
        self.resize(1280, 800)

        self._historial: list[str] = []
        self._build_menu()
        self._build_toolbar()
        self._build_central()
        self._build_historial_dock()
        self._build_statusbar()
        self._aplicar_tema()

    # ── Menú ──────────────────────────────────────────────────────────────────

    def _build_menu(self):
        bar = self.menuBar()

        # Archivo
        m_arch = bar.addMenu("Archivo")
        act_quit = QAction("Salir", self)
        act_quit.setShortcut("Ctrl+Q")
        act_quit.triggered.connect(self.close)
        m_arch.addAction(act_quit)

        # Ver
        m_ver = bar.addMenu("Ver")
        act_hist = QAction("Mostrar/Ocultar Historial", self)
        act_hist.triggered.connect(self._toggle_historial)
        m_ver.addAction(act_hist)

        # Temas
        m_temas = bar.addMenu("Temas")
        for key, data in TM.THEMES.items():
            act = QAction(data["label"], self)
            act.setData(key)
            act.triggered.connect(lambda checked, k=key: self._cambiar_tema(k))
            m_temas.addAction(act)

        # Ayuda
        m_help = bar.addMenu("Ayuda")
        act_about = QAction("Acerca de…", self)
        act_about.triggered.connect(self._mostrar_acerca)
        m_help.addAction(act_about)

    # ── Toolbar ───────────────────────────────────────────────────────────────

    def _build_toolbar(self):
        tb = self.addToolBar("Principal")
        tb.setMovable(False)
        tb.setIconSize(QSize(18, 18))

        lbl = QLabel("  Tema: ")
        tb.addWidget(lbl)

        self.cb_tema = QComboBox()
        self.cb_tema.setSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Fixed)
        for key, data in TM.THEMES.items():
            self.cb_tema.addItem(data["label"], key)
        self.cb_tema.currentIndexChanged.connect(
            lambda: self._cambiar_tema(self.cb_tema.currentData())
        )
        tb.addWidget(self.cb_tema)

        tb.addSeparator()

        btn_limpiar = QPushButton("🗑 Limpiar historial")
        btn_limpiar.setSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Fixed)
        btn_limpiar.clicked.connect(lambda: (
            self._historial.clear(),
            self.list_hist.clear(),
        ))
        tb.addWidget(btn_limpiar)

    # ── Central (tabs) ────────────────────────────────────────────────────────

    def _build_central(self):
        central = QWidget()
        lay = QVBoxLayout(central)
        lay.setContentsMargins(8, 8, 8, 4)

        self.tabs = QTabWidget()
        self.tabs.setTabPosition(QTabWidget.TabPosition.North)

        # Instanciar cada módulo con callback de historial
        self.tab_raices        = TabRaices(historial_fn=self._registrar_historial)
        self.tab_interpolacion = TabInterpolacion(historial_fn=self._registrar_historial)
        self.tab_sistemas      = TabSistemas(historial_fn=self._registrar_historial)
        self.tab_integracion   = TabIntegracion(historial_fn=self._registrar_historial)
        self.tab_edo           = TabEDO(historial_fn=self._registrar_historial)

        self.tabs.addTab(self.tab_raices,        "🔍 Raíces")
        self.tabs.addTab(self.tab_interpolacion, "📐 Interpolación")
        self.tabs.addTab(self.tab_sistemas,      "🔢 Sistemas Ec.")
        self.tabs.addTab(self.tab_integracion,   "∫  Integración")
        self.tabs.addTab(self.tab_edo,           "📈 EDO")

        lay.addWidget(self.tabs)
        self.setCentralWidget(central)

        self._all_tabs = {
            "raices":        self.tab_raices,
            "interpolacion": self.tab_interpolacion,
            "sistemas":      self.tab_sistemas,
            "integracion":   self.tab_integracion,
            "edo":           self.tab_edo,
        }

    # ── Historial dock ────────────────────────────────────────────────────────

    def _build_historial_dock(self):
        dock = QDockWidget("Historial de cálculos", self)
        dock.setAllowedAreas(
            Qt.DockWidgetArea.RightDockWidgetArea |
            Qt.DockWidgetArea.LeftDockWidgetArea
        )
        self._dock_hist = dock

        widget = QWidget()
        vl = QVBoxLayout(widget)
        vl.addWidget(QLabel("Últimas operaciones:"))
        self.list_hist = QListWidget()
        self.list_hist.setAlternatingRowColors(True)
        vl.addWidget(self.list_hist)
        dock.setWidget(widget)
        self.addDockWidget(Qt.DockWidgetArea.RightDockWidgetArea, dock)

    def _toggle_historial(self):
        self._dock_hist.setVisible(not self._dock_hist.isVisible())

    def _registrar_historial(self, modulo: str, metodo: str, resumen: str):
        now = datetime.datetime.now().strftime("%H:%M:%S")
        entrada = f"[{now}] {modulo} | {metodo} → {resumen}"
        self._historial.append(entrada)
        item = QListWidgetItem(entrada)
        self.list_hist.insertItem(0, item)
        if self.list_hist.count() > 200:
            self.list_hist.takeItem(self.list_hist.count() - 1)
        self.statusBar().showMessage(f"Último: {modulo} — {resumen}", 4000)

    # ── Status bar ────────────────────────────────────────────────────────────

    def _build_statusbar(self):
        self.statusBar().showMessage(
            "Listo  |  Proyecto Final — Métodos Numéricos con Python"
        )

    # ── Temas ─────────────────────────────────────────────────────────────────

    def _cambiar_tema(self, key: str):
        TM.set_theme(key)
        self._aplicar_tema()
        for i in range(self.cb_tema.count()):
            if self.cb_tema.itemData(i) == key:
                self.cb_tema.blockSignals(True)
                self.cb_tema.setCurrentIndex(i)
                self.cb_tema.blockSignals(False)
                break
        for tab in self._all_tabs.values():
            if hasattr(tab, "apply_theme"):
                tab.apply_theme()

    def _aplicar_tema(self):
        t = TM.get_theme()
        self.setStyleSheet(TM.build_stylesheet(t))

    # ── Acerca de ─────────────────────────────────────────────────────────────

    def _mostrar_acerca(self):
        QMessageBox.information(
            self, "Acerca del proyecto",
            "<b>Proyecto Final — Métodos Numéricos con Python</b><br><br>"
            "<b>Universidad Mariano Gálvez</b><br>"
            "Facultad de Ingeniería en Sistemas de Información<br>"
            "Curso 021 — Métodos Numéricos con Python<br><br>"
            "<b>Módulos implementados:</b><br>"
            "• Módulo 1: Raíces (Bisección, Newton-Raphson, Secante, Regula Falsi, Punto Fijo)<br>"
            "• Módulo 2: Interpolación (Lagrange, Newton, Spline Cúbico, Mínimos Cuadrados)<br>"
            "• Módulo 3: Sistemas Lineales (Gauss, Gauss-Jordan, LU, Jacobi, Gauss-Seidel)<br>"
            "• Módulo 4: Integración y Derivación (Trapecio, Simpson 1/3 y 3/8, Gauss-Legendre)<br>"
            "• Módulo 5: EDO (Euler, Euler Mejorado, RK4, RK45, solve_ivp)<br><br>"
            "<b>Tecnologías:</b> Python 3.x · PyQt6 · NumPy · SciPy · Matplotlib · SymPy",
        )


def main():
    app = QApplication(sys.argv)
    app.setApplicationName("Métodos Numéricos — Proyecto Final")
    app.setApplicationVersion("1.0.0")
    font = QFont("Segoe UI", 10)
    app.setFont(font)
    window = VentanaPrincipal()
    window.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
