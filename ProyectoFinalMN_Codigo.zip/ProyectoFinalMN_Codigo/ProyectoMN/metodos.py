"""
PROYECTO FINAL — Métodos Numéricos
Universidad Mariano Gálvez — Curso 021

Módulo central: metodos.py
Implementa TODOS los métodos numéricos del proyecto en un solo archivo modular.

Módulos:
    - Raíces de Ecuaciones
    - Interpolación y Ajuste de Curvas
    - Sistemas de Ecuaciones Lineales
    - Derivación e Integración Numérica
    - Ecuaciones Diferenciales Ordinarias
"""

import numpy as np


# ══════════════════════════════════════════════════════════════════════════════
#  MÓDULO 1: RAÍCES DE ECUACIONES
# ══════════════════════════════════════════════════════════════════════════════

def biseccion(f, a: float, b: float, tol: float = 1e-6, max_iter: int = 100) -> dict:
    """
    Método de Bisección para encontrar raíces de f(x) = 0.

    Parámetros:
        f        : función continua en [a, b]
        a, b     : extremos del intervalo (f(a)*f(b) < 0)
        tol      : tolerancia de convergencia
        max_iter : número máximo de iteraciones

    Retorna:
        dict con raíz, iteraciones, error y tabla completa de historial
    """
    if f(a) * f(b) >= 0:
        raise ValueError("f(a) y f(b) deben tener signos opuestos.")

    tabla = []
    error = float("inf")
    c_prev = None

    for i in range(1, max_iter + 1):
        c = (a + b) / 2.0
        fc = f(c)

        if c_prev is not None:
            error = abs(c - c_prev)

        tabla.append({
            "iteracion": i,
            "a": a,
            "b": b,
            "c": c,
            "f(c)": fc,
            "error": error if c_prev is not None else None,
        })

        if abs(fc) < tol or error < tol:
            return {
                "raiz": c,
                "iteraciones": i,
                "f(raiz)": fc,
                "error_final": error,
                "tabla": tabla,
                "convergencia": True,
            }

        if f(a) * fc < 0:
            b = c
        else:
            a = c

        c_prev = c

    return {
        "raiz": c,
        "iteraciones": max_iter,
        "f(raiz)": f(c),
        "error_final": error,
        "tabla": tabla,
        "convergencia": False,
    }


def newton_raphson(f, df, x0: float, tol: float = 1e-6, max_iter: int = 100) -> dict:
    """
    Método de Newton-Raphson para encontrar raíces de f(x) = 0.

    Parámetros:
        f        : función
        df       : derivada de f
        x0       : estimación inicial
        tol      : tolerancia de convergencia
        max_iter : número máximo de iteraciones

    Retorna:
        dict con raíz, iteraciones, error y tabla completa
    """
    tabla = []
    x = x0

    for i in range(1, max_iter + 1):
        fx = f(x)
        dfx = df(x)

        if abs(dfx) < 1e-14:
            raise ZeroDivisionError(f"Derivada cercana a cero en x = {x}")

        x_nuevo = x - fx / dfx
        error = abs(x_nuevo - x)

        tabla.append({
            "iteracion": i,
            "x": x,
            "f(x)": fx,
            "f'(x)": dfx,
            "x_nuevo": x_nuevo,
            "error": error,
        })

        if error < tol or abs(fx) < tol:
            return {
                "raiz": x_nuevo,
                "iteraciones": i,
                "f(raiz)": f(x_nuevo),
                "error_final": error,
                "tabla": tabla,
                "convergencia": True,
            }

        x = x_nuevo

    return {
        "raiz": x,
        "iteraciones": max_iter,
        "f(raiz)": f(x),
        "error_final": error,
        "tabla": tabla,
        "convergencia": False,
    }


def secante(f, x0: float, x1: float, tol: float = 1e-6, max_iter: int = 100) -> dict:
    """
    Método de la Secante para encontrar raíces de f(x) = 0.

    Parámetros:
        f        : función
        x0, x1   : dos estimaciones iniciales
        tol      : tolerancia de convergencia
        max_iter : número máximo de iteraciones

    Retorna:
        dict con raíz, iteraciones, error y tabla completa
    """
    tabla = []

    for i in range(1, max_iter + 1):
        f0 = f(x0)
        f1 = f(x1)

        denom = f1 - f0
        if abs(denom) < 1e-14:
            raise ZeroDivisionError(
                f"División por cero en iteración {i}: f(x1)-f(x0) ≈ 0"
            )

        x2 = x1 - f1 * (x1 - x0) / denom
        error = abs(x2 - x1)

        tabla.append({
            "iteracion": i,
            "x0": x0,
            "x1": x1,
            "x2": x2,
            "f(x2)": f(x2),
            "error": error,
        })

        if error < tol or abs(f(x2)) < tol:
            return {
                "raiz": x2,
                "iteraciones": i,
                "f(raiz)": f(x2),
                "error_final": error,
                "tabla": tabla,
                "convergencia": True,
            }

        x0, x1 = x1, x2

    return {
        "raiz": x2,
        "iteraciones": max_iter,
        "f(raiz)": f(x2),
        "error_final": error,
        "tabla": tabla,
        "convergencia": False,
    }


def regula_falsi(f, a: float, b: float, tol: float = 1e-6, max_iter: int = 100) -> dict:
    """
    Método de Regula Falsi (Falsa Posición) para encontrar raíces de f(x) = 0.

    Parámetros:
        f        : función continua en [a, b]
        a, b     : extremos del intervalo (f(a)*f(b) < 0)
        tol      : tolerancia de convergencia
        max_iter : número máximo de iteraciones

    Retorna:
        dict con raíz, iteraciones, error y tabla completa
    """
    if f(a) * f(b) >= 0:
        raise ValueError("f(a) y f(b) deben tener signos opuestos.")

    tabla = []
    c = a

    for i in range(1, max_iter + 1):
        fa, fb = f(a), f(b)
        c = b - fb * (b - a) / (fb - fa)
        fc = f(c)
        error = abs(fc)

        tabla.append({
            "iteracion": i,
            "a": a,
            "b": b,
            "c": c,
            "f(c)": fc,
            "error": error,
        })

        if abs(fc) < tol or abs(b - a) < tol:
            return {
                "raiz": c,
                "iteraciones": i,
                "f(raiz)": fc,
                "error_final": error,
                "tabla": tabla,
                "convergencia": True,
            }

        if fa * fc < 0:
            b = c
        else:
            a = c

    return {
        "raiz": c,
        "iteraciones": max_iter,
        "f(raiz)": f(c),
        "error_final": error,
        "tabla": tabla,
        "convergencia": False,
    }


def punto_fijo(g, x0: float, tol: float = 1e-6, max_iter: int = 100) -> dict:
    """
    Método de Punto Fijo para encontrar x tal que g(x) = x.

    Parámetros:
        g        : función de iteración g(x)
        x0       : estimación inicial
        tol      : tolerancia de convergencia
        max_iter : número máximo de iteraciones

    Retorna:
        dict con raíz, iteraciones, error y tabla completa
    """
    tabla = []
    x = x0

    for i in range(1, max_iter + 1):
        x_nuevo = g(x)
        error = abs(x_nuevo - x)

        tabla.append({
            "iteracion": i,
            "x": x,
            "g(x)": x_nuevo,
            "error": error,
        })

        if error < tol:
            return {
                "raiz": x_nuevo,
                "iteraciones": i,
                "error_final": error,
                "tabla": tabla,
                "convergencia": True,
            }

        x = x_nuevo

    return {
        "raiz": x,
        "iteraciones": max_iter,
        "error_final": error,
        "tabla": tabla,
        "convergencia": False,
    }


# ══════════════════════════════════════════════════════════════════════════════
#  MÓDULO 2: INTERPOLACIÓN Y AJUSTE DE CURVAS
# ══════════════════════════════════════════════════════════════════════════════

def lagrange(x_datos, y_datos, x_eval) -> dict:
    """
    Interpolación de Lagrange.

    Parámetros:
        x_datos : array de nodos de interpolación
        y_datos : array de valores en los nodos
        x_eval  : punto(s) donde evaluar el polinomio (escalar o array)

    Retorna:
        dict con valor interpolado, polinomios base L_i, grado y nodos
    """
    x_datos = np.array(x_datos, dtype=float)
    y_datos = np.array(y_datos, dtype=float)
    n = len(x_datos)

    if len(x_datos) != len(y_datos):
        raise ValueError("x_datos e y_datos deben tener la misma longitud.")

    escalar = np.isscalar(x_eval)
    x_eval = np.atleast_1d(np.array(x_eval, dtype=float))

    resultado = np.zeros_like(x_eval)
    L_matrix = np.zeros((len(x_eval), n))

    for i in range(n):
        L_i = np.ones_like(x_eval)
        for j in range(n):
            if i != j:
                denom = x_datos[i] - x_datos[j]
                if abs(denom) < 1e-14:
                    raise ValueError(
                        f"Nodos duplicados: x[{i}] = x[{j}] = {x_datos[i]}"
                    )
                L_i *= (x_eval - x_datos[j]) / denom
        L_matrix[:, i] = L_i
        resultado += y_datos[i] * L_i

    return {
        "x_eval": x_eval if not escalar else x_eval[0],
        "y_interpolado": resultado if not escalar else resultado[0],
        "L_polinomios": L_matrix if not escalar else L_matrix[0],
        "grado": n - 1,
        "nodos": x_datos,
        "valores": y_datos,
    }


def diferencias_divididas(x_datos, y_datos) -> dict:
    """
    Tabla de diferencias divididas de Newton.

    Parámetros:
        x_datos : array de nodos
        y_datos : array de valores en los nodos

    Retorna:
        dict con tabla triangular de diferencias divididas y coeficientes
    """
    x_datos = np.array(x_datos, dtype=float)
    y_datos = np.array(y_datos, dtype=float)
    n = len(x_datos)

    if len(x_datos) != len(y_datos):
        raise ValueError("x_datos e y_datos deben tener la misma longitud.")

    tabla = np.zeros((n, n))
    tabla[:, 0] = y_datos.copy()

    for j in range(1, n):
        for i in range(n - j):
            denom = x_datos[i + j] - x_datos[i]
            if abs(denom) < 1e-14:
                raise ValueError(
                    f"Nodos duplicados detectados en índices {i} y {i + j}."
                )
            tabla[i, j] = (tabla[i + 1, j - 1] - tabla[i, j - 1]) / denom

    coeficientes = tabla[0, :].copy()

    return {
        "tabla": tabla,
        "coeficientes": coeficientes,
        "nodos": x_datos,
        "orden": n - 1,
    }


def newton_interpolacion(x_datos, y_datos, x_eval) -> dict:
    """
    Interpolación de Newton con diferencias divididas (forma de Horner).

    Parámetros:
        x_datos : array de nodos
        y_datos : array de valores en los nodos
        x_eval  : punto(s) donde evaluar (escalar o array)

    Retorna:
        dict con valor interpolado, coeficientes y tabla de diferencias divididas
    """
    x_datos = np.array(x_datos, dtype=float)
    y_datos = np.array(y_datos, dtype=float)

    dd = diferencias_divididas(x_datos, y_datos)
    coef = dd["coeficientes"]
    n = len(coef)

    escalar = np.isscalar(x_eval)
    x_eval = np.atleast_1d(np.array(x_eval, dtype=float))

    # Evaluación por esquema de Horner
    resultado = np.full_like(x_eval, coef[n - 1])
    for k in range(n - 2, -1, -1):
        resultado = resultado * (x_eval - x_datos[k]) + coef[k]

    return {
        "x_eval": x_eval if not escalar else x_eval[0],
        "y_interpolado": resultado if not escalar else resultado[0],
        "coeficientes": coef,
        "tabla_diferencias": dd["tabla"],
        "nodos": x_datos,
        "grado": n - 1,
    }


# ══════════════════════════════════════════════════════════════════════════════
#  MÓDULO 3: SISTEMAS DE ECUACIONES LINEALES
# ══════════════════════════════════════════════════════════════════════════════

def gauss_eliminacion(A: np.ndarray, b: np.ndarray) -> dict:
    """
    Eliminación Gaussiana con pivoteo parcial.

    Parámetros:
        A : matriz de coeficientes (n x n)
        b : vector de términos independientes (n,)

    Retorna:
        dict con solución, residuo y pasos de eliminación
    """
    A = np.array(A, dtype=float)
    b = np.array(b, dtype=float)
    n = len(b)

    Ab = np.hstack([A, b.reshape(-1, 1)])

    for col in range(n):
        pivot = np.argmax(np.abs(Ab[col:, col])) + col
        Ab[[col, pivot]] = Ab[[pivot, col]]
        if abs(Ab[col, col]) < 1e-14:
            raise ValueError("Sistema singular o casi singular.")
        for row in range(col + 1, n):
            factor = Ab[row, col] / Ab[col, col]
            Ab[row] -= factor * Ab[col]

    x = np.zeros(n)
    for i in range(n - 1, -1, -1):
        x[i] = (Ab[i, -1] - Ab[i, i + 1:n] @ x[i + 1:]) / Ab[i, i]

    return {
        "solucion": x,
        "residuo": np.linalg.norm(A @ x - b),
        "convergencia": True,
    }


def gauss_jordan(A: np.ndarray, b: np.ndarray) -> dict:
    """
    Eliminación Gauss-Jordan con pivoteo parcial.

    Parámetros:
        A : matriz de coeficientes (n x n)
        b : vector de términos independientes (n,)

    Retorna:
        dict con solución y residuo
    """
    A = np.array(A, dtype=float)
    b = np.array(b, dtype=float)
    n = len(b)

    Ab = np.hstack([A, b.reshape(-1, 1)])

    for col in range(n):
        pivot = np.argmax(np.abs(Ab[col:, col])) + col
        Ab[[col, pivot]] = Ab[[pivot, col]]
        if abs(Ab[col, col]) < 1e-14:
            raise ValueError("Sistema singular o casi singular.")
        Ab[col] /= Ab[col, col]
        for row in range(n):
            if row != col:
                Ab[row] -= Ab[row, col] * Ab[col]

    x = Ab[:, -1]

    return {
        "solucion": x,
        "residuo": np.linalg.norm(A @ x - b),
        "convergencia": True,
    }


def factorizacion_lu(A, b=None) -> dict:
    """
    Factorización LU de Doolittle (sin pivoteo parcial).
    Resuelve Ax = b si se proporciona b.

    Descomposición: A = L · U
        L : triangular inferior con diagonal de unos
        U : triangular superior

    Parámetros:
        A : matriz cuadrada (n x n)
        b : vector independiente opcional (n,) — si se da, resuelve Ax = b

    Retorna:
        dict con L, U, determinante y opcionalmente la solución x
    """
    A = np.array(A, dtype=float)
    n = A.shape[0]

    if A.shape[0] != A.shape[1]:
        raise ValueError("A debe ser una matriz cuadrada.")

    L = np.zeros((n, n))
    U = np.zeros((n, n))

    for i in range(n):
        L[i, i] = 1.0

        for k in range(i, n):
            suma = sum(L[i, s] * U[s, k] for s in range(i))
            U[i, k] = A[i, k] - suma

        if abs(U[i, i]) < 1e-14:
            raise ValueError(
                f"Pivote nulo en U[{i},{i}]. Considere usar pivoteo."
            )

        for k in range(i + 1, n):
            suma = sum(L[k, s] * U[s, i] for s in range(i))
            L[k, i] = (A[k, i] - suma) / U[i, i]

    resultado = {
        "L": L,
        "U": U,
        "det_A": np.prod(np.diag(U)),
    }

    if b is not None:
        b = np.array(b, dtype=float)

        # Sustitución progresiva: L·y = b
        y = np.zeros(n)
        for i in range(n):
            y[i] = b[i] - sum(L[i, j] * y[j] for j in range(i))

        # Sustitución regresiva: U·x = y
        x = np.zeros(n)
        for i in range(n - 1, -1, -1):
            x[i] = (y[i] - sum(U[i, j] * x[j] for j in range(i + 1, n))) / U[i, i]

        resultado["solucion"] = x
        resultado["y_intermedio"] = y
        resultado["residuo"] = np.linalg.norm(A @ x - b)
        resultado["convergencia"] = True

    return resultado


def jacobi(
    A: np.ndarray,
    b: np.ndarray,
    x0=None,
    tol: float = 1e-6,
    max_iter: int = 100,
) -> dict:
    """
    Método iterativo de Jacobi.

    Parámetros:
        A        : matriz de coeficientes (n x n)
        b        : vector de términos independientes (n,)
        x0       : estimación inicial (None → vector de ceros)
        tol      : tolerancia de convergencia
        max_iter : número máximo de iteraciones

    Retorna:
        dict con solución, iteraciones, errores y tabla de convergencia
    """
    A = np.array(A, dtype=float)
    b = np.array(b, dtype=float)
    n = len(b)

    x = np.zeros(n) if x0 is None else np.array(x0, dtype=float).copy()
    tabla = []

    for it in range(1, max_iter + 1):
        x_new = np.zeros(n)
        for i in range(n):
            s = sum(A[i, j] * x[j] for j in range(n) if j != i)
            x_new[i] = (b[i] - s) / A[i, i]

        error = np.linalg.norm(x_new - x, ord=np.inf)
        tabla.append({"iteracion": it, "x": x_new.copy(), "error": error})

        if error < tol:
            return {
                "solucion": x_new,
                "iteraciones": it,
                "error_final": error,
                "tabla": tabla,
                "residuo": np.linalg.norm(A @ x_new - b),
                "convergencia": True,
            }
        x = x_new

    return {
        "solucion": x,
        "iteraciones": max_iter,
        "error_final": error,
        "tabla": tabla,
        "residuo": np.linalg.norm(A @ x - b),
        "convergencia": False,
    }


def gauss_seidel(
    A,
    b,
    x0=None,
    tol: float = 1e-6,
    max_iter: int = 100,
    w: float = 1.0,
) -> dict:
    """
    Método iterativo de Gauss-Seidel (con relajación SOR opcional).

    Parámetros:
        A        : matriz de coeficientes (n x n)
        b        : vector de términos independientes (n,)
        x0       : estimación inicial (None → vector de ceros)
        tol      : tolerancia de convergencia
        max_iter : número máximo de iteraciones
        w        : factor de relajación (1.0 = Gauss-Seidel puro)

    Retorna:
        dict con solución, iteraciones, errores y tabla de convergencia
    """
    A = np.array(A, dtype=float)
    b = np.array(b, dtype=float)
    n = len(b)

    if A.shape != (n, n):
        raise ValueError("A debe ser una matriz cuadrada n×n.")

    diag = np.diag(A)
    if np.any(np.abs(diag) < 1e-14):
        raise ValueError("La diagonal contiene elementos nulos o casi nulos.")

    x = np.zeros(n) if x0 is None else np.array(x0, dtype=float).copy()
    tabla = []

    for it in range(1, max_iter + 1):
        x_anterior = x.copy()

        for i in range(n):
            suma = b[i]
            for j in range(n):
                if j != i:
                    suma -= A[i, j] * x[j]
            x_gs = suma / A[i, i]
            x[i] = w * x_gs + (1 - w) * x[i]

        error = np.linalg.norm(x - x_anterior, ord=np.inf)
        tabla.append({"iteracion": it, "x": x.copy(), "error": error})

        if error < tol:
            return {
                "solucion": x,
                "iteraciones": it,
                "error_final": error,
                "tabla": tabla,
                "residuo": np.linalg.norm(A @ x - b),
                "convergencia": True,
            }

    return {
        "solucion": x,
        "iteraciones": max_iter,
        "error_final": error,
        "tabla": tabla,
        "residuo": np.linalg.norm(A @ x - b),
        "convergencia": False,
    }


# ══════════════════════════════════════════════════════════════════════════════
#  MÓDULO 4: DERIVACIÓN E INTEGRACIÓN NUMÉRICA
# ══════════════════════════════════════════════════════════════════════════════

# ── Derivación ────────────────────────────────────────────────────────────────

def derivada_adelante(f, x: float, h: float = 1e-5) -> float:
    """
    Diferencia finita hacia adelante de primer orden. Error O(h).
    """
    return (f(x + h) - f(x)) / h


def derivada_atras(f, x: float, h: float = 1e-5) -> float:
    """
    Diferencia finita hacia atrás de primer orden. Error O(h).
    """
    return (f(x) - f(x - h)) / h


def derivada_centrada(f, x: float, h: float = 1e-5) -> float:
    """
    Diferencia finita centrada de segundo orden. Error O(h²).
    """
    return (f(x + h) - f(x - h)) / (2 * h)


def segunda_derivada(f, x: float, h: float = 1e-5) -> float:
    """
    Segunda derivada por diferencias finitas centradas. Error O(h²).
    """
    return (f(x + h) - 2 * f(x) + f(x - h)) / h ** 2


def derivada_orden4(f, x: float, h: float = 1e-5) -> float:
    """
    Primera derivada con fórmula de cinco puntos (centrada). Error O(h⁴).
    """
    return (-f(x + 2 * h) + 8 * f(x + h) - 8 * f(x - h) + f(x - 2 * h)) / (12 * h)


def derivadas_tabla(x_datos, y_datos) -> np.ndarray:
    """
    Derivadas numéricas a partir de datos discretos usando diferencias finitas.
    - Extremos: diferencias hacia adelante / atrás
    - Interior: diferencias centradas

    Parámetros:
        x_datos : array de abscisas
        y_datos : array de ordenadas

    Retorna:
        array con la derivada estimada en cada punto
    """
    x = np.array(x_datos, dtype=float)
    y = np.array(y_datos, dtype=float)
    n = len(x)
    dy = np.zeros(n)

    dy[0] = (y[1] - y[0]) / (x[1] - x[0])
    for i in range(1, n - 1):
        dy[i] = (y[i + 1] - y[i - 1]) / (x[i + 1] - x[i - 1])
    dy[-1] = (y[-1] - y[-2]) / (x[-1] - x[-2])

    return dy


# ── Integración ────────────────────────────────────────────────────────────────

def trapecio(f, a: float, b: float, n: int = 100) -> dict:
    """
    Regla del Trapecio compuesta.

    Parámetros:
        f    : función a integrar
        a, b : límites de integración
        n    : número de subintervalos (n ≥ 1)

    Retorna:
        dict con aproximación, nodos y valores
    """
    if n < 1:
        raise ValueError("n debe ser al menos 1.")
    x = np.linspace(a, b, n + 1)
    y = np.array([f(xi) for xi in x])
    h = (b - a) / n
    integral = h * (y[0] / 2 + np.sum(y[1:-1]) + y[-1] / 2)
    return {
        "integral": integral,
        "h": h,
        "n": n,
        "nodos": x,
        "valores": y,
        "metodo": "Trapecio compuesto",
    }


def simpson_13(f, a: float, b: float, n: int = 100) -> dict:
    """
    Regla de Simpson 1/3 compuesta. Requiere n par.

    Parámetros:
        f    : función a integrar
        a, b : límites de integración
        n    : número de subintervalos (debe ser par)

    Retorna:
        dict con aproximación, nodos y valores
    """
    if n % 2 != 0:
        n += 1
    x = np.linspace(a, b, n + 1)
    y = np.array([f(xi) for xi in x])
    h = (b - a) / n
    integral = h / 3 * (
        y[0] + 4 * np.sum(y[1:-1:2]) + 2 * np.sum(y[2:-2:2]) + y[-1]
    )
    return {
        "integral": integral,
        "h": h,
        "n": n,
        "nodos": x,
        "valores": y,
        "metodo": "Simpson 1/3 compuesto",
    }


def simpson_38(f, a: float, b: float, n: int = 99) -> dict:
    """
    Regla de Simpson 3/8 compuesta. Requiere n múltiplo de 3.

    Parámetros:
        f    : función a integrar
        a, b : límites de integración
        n    : número de subintervalos (múltiplo de 3)

    Retorna:
        dict con aproximación, nodos y valores
    """
    if n % 3 != 0:
        n = n + (3 - n % 3)

    x = np.linspace(a, b, n + 1)
    y = np.array([f(xi) for xi in x])
    h = (b - a) / n

    integral = y[0] + y[-1]
    for i in range(1, n):
        integral += 2 * y[i] if i % 3 == 0 else 3 * y[i]
    integral *= 3 * h / 8

    return {
        "integral": integral,
        "h": h,
        "n": n,
        "nodos": x,
        "valores": y,
        "metodo": "Simpson 3/8 compuesto",
    }


def gauss_legendre(f, a: float, b: float, n: int = 5) -> dict:
    """
    Cuadratura de Gauss-Legendre de n puntos.

    Transforma el intervalo [a, b] a [-1, 1] y aplica
    los nodos y pesos de Gauss-Legendre.

    Parámetros:
        f    : función a integrar
        a, b : límites de integración
        n    : número de puntos de cuadratura (1–20)

    Retorna:
        dict con aproximación, nodos transformados y pesos
    """
    nodos_ref, pesos = np.polynomial.legendre.leggauss(n)

    factor = (b - a) / 2.0
    centro = (a + b) / 2.0

    x_transform = factor * nodos_ref + centro
    y_vals = np.array([f(xi) for xi in x_transform])

    integral = factor * np.dot(pesos, y_vals)

    return {
        "integral": integral,
        "n_puntos": n,
        "nodos_referencia": nodos_ref,
        "nodos_transformados": x_transform,
        "pesos": pesos,
        "valores": y_vals,
        "metodo": f"Gauss-Legendre ({n} puntos)",
    }


def trapecio_datos(x_datos, y_datos) -> float:
    """
    Regla del Trapecio para datos discretos (espaciado no uniforme).

    Parámetros:
        x_datos : abscisas
        y_datos : ordenadas

    Retorna:
        valor de la integral aproximada
    """
    x = np.array(x_datos, dtype=float)
    y = np.array(y_datos, dtype=float)
    return float(np.trapz(y, x))


# ══════════════════════════════════════════════════════════════════════════════
#  MÓDULO 5: ECUACIONES DIFERENCIALES ORDINARIAS
# ══════════════════════════════════════════════════════════════════════════════

def euler(f, t0: float, y0, tf: float, h: float) -> dict:
    """
    Método de Euler Explícito para resolver:
        dy/dt = f(t, y),  y(t0) = y0

    Parámetros:
        f  : función f(t, y) que define la EDO
        t0 : tiempo inicial
        y0 : condición inicial (escalar o array para sistemas)
        tf : tiempo final
        h  : tamaño de paso

    Retorna:
        dict con arrays de tiempo, solución y tabla de pasos
    """
    escalar = np.isscalar(y0)
    t = np.arange(t0, tf + h * 1e-10, h)
    n = len(t)

    y0_arr = np.atleast_1d(np.array(y0, dtype=float))
    dim = len(y0_arr)

    Y = np.zeros((n, dim))
    Y[0] = y0_arr

    tabla = [{"i": 0, "t": t[0],
              "y": Y[0].copy() if not escalar else float(Y[0][0]),
              "f(t,y)": None}]

    for i in range(n - 1):
        fi = np.atleast_1d(f(t[i], Y[i] if not escalar else float(Y[i][0])))
        Y[i + 1] = Y[i] + h * fi
        tabla.append({
            "i": i + 1,
            "t": t[i + 1],
            "y": Y[i + 1].copy() if not escalar else float(Y[i + 1][0]),
            "f(t,y)": fi.copy() if not escalar else float(fi[0]),
        })

    sol = Y[:, 0] if escalar else Y

    return {
        "t": t, "y": sol, "h": h, "pasos": n - 1,
        "tabla": tabla, "metodo": "Euler explícito",
    }


def euler_mejorado(f, t0: float, y0, tf: float, h: float) -> dict:
    """
    Método de Euler Mejorado (Heun / Predictor-Corrector de orden 2).

    Parámetros:
        f  : función f(t, y)
        t0 : tiempo inicial
        y0 : condición inicial
        tf : tiempo final
        h  : tamaño de paso

    Retorna:
        dict con arrays de tiempo, solución y tabla de pasos
    """
    escalar = np.isscalar(y0)
    t = np.arange(t0, tf + h * 1e-10, h)
    n = len(t)

    y0_arr = np.atleast_1d(np.array(y0, dtype=float))
    dim = len(y0_arr)

    Y = np.zeros((n, dim))
    Y[0] = y0_arr

    tabla = [{"i": 0, "t": t[0],
              "y": Y[0].copy() if not escalar else float(Y[0][0])}]

    for i in range(n - 1):
        yi = Y[i]
        ti = t[i]
        ti1 = t[i + 1]

        k1 = np.atleast_1d(f(ti, yi if not escalar else float(yi[0])))
        y_pred = yi + h * k1
        k2 = np.atleast_1d(f(ti1, y_pred if not escalar else float(y_pred[0])))
        Y[i + 1] = yi + h / 2 * (k1 + k2)

        tabla.append({
            "i": i + 1, "t": ti1,
            "y": Y[i + 1].copy() if not escalar else float(Y[i + 1][0]),
            "k1": k1.copy() if not escalar else float(k1[0]),
            "k2": k2.copy() if not escalar else float(k2[0]),
        })

    sol = Y[:, 0] if escalar else Y

    return {
        "t": t, "y": sol, "h": h, "pasos": n - 1,
        "tabla": tabla, "metodo": "Euler mejorado (Heun)",
    }


def runge_kutta_4(f, t0: float, y0, tf: float, h: float) -> dict:
    """
    Método de Runge-Kutta de orden 4 (RK4 clásico).

    Resuelve:  dy/dt = f(t, y),  y(t0) = y0
    Soporta EDOs escalares y sistemas vectoriales.

    Coeficientes:
        k1 = h·f(tᵢ, yᵢ)
        k2 = h·f(tᵢ + h/2, yᵢ + k1/2)
        k3 = h·f(tᵢ + h/2, yᵢ + k2/2)
        k4 = h·f(tᵢ + h,   yᵢ + k3)
        yᵢ₊₁ = yᵢ + (k1 + 2k2 + 2k3 + k4) / 6

    Parámetros:
        f  : función f(t, y)
        t0 : tiempo inicial
        y0 : condición inicial (escalar o array)
        tf : tiempo final
        h  : tamaño de paso

    Retorna:
        dict con arrays de tiempo, solución, pendientes k y tabla de pasos
    """
    escalar = np.isscalar(y0)
    t = np.arange(t0, tf + h * 1e-10, h)
    n = len(t)

    y0_arr = np.atleast_1d(np.array(y0, dtype=float))
    dim = len(y0_arr)

    Y = np.zeros((n, dim))
    Y[0] = y0_arr

    K1 = np.zeros((n - 1, dim))
    K2 = np.zeros((n - 1, dim))
    K3 = np.zeros((n - 1, dim))
    K4 = np.zeros((n - 1, dim))

    tabla = [{"i": 0, "t": t[0],
              "y": Y[0].copy() if not escalar else float(Y[0][0])}]

    for i in range(n - 1):
        ti = t[i]
        yi = Y[i]

        def _eval(t_val, y_val):
            arg = y_val if not escalar else float(y_val[0])
            return np.atleast_1d(f(t_val, arg))

        k1 = h * _eval(ti, yi)
        k2 = h * _eval(ti + h / 2, yi + k1 / 2)
        k3 = h * _eval(ti + h / 2, yi + k2 / 2)
        k4 = h * _eval(ti + h, yi + k3)

        Y[i + 1] = yi + (k1 + 2 * k2 + 2 * k3 + k4) / 6

        K1[i], K2[i], K3[i], K4[i] = k1, k2, k3, k4

        tabla.append({
            "i": i + 1, "t": t[i + 1],
            "y": Y[i + 1].copy() if not escalar else float(Y[i + 1][0]),
            "k1": k1.copy() if not escalar else float(k1[0]),
            "k2": k2.copy() if not escalar else float(k2[0]),
            "k3": k3.copy() if not escalar else float(k3[0]),
            "k4": k4.copy() if not escalar else float(k4[0]),
        })

    sol = Y[:, 0] if escalar else Y

    return {
        "t": t, "y": sol, "h": h, "pasos": n - 1,
        "K1": K1[:, 0] if escalar else K1,
        "K2": K2[:, 0] if escalar else K2,
        "K3": K3[:, 0] if escalar else K3,
        "K4": K4[:, 0] if escalar else K4,
        "tabla": tabla, "metodo": "Runge-Kutta orden 4 (clásico)",
    }


def rk4_sistema(F, t0: float, Y0, tf: float, h: float) -> dict:
    """
    Runge-Kutta orden 4 para sistemas de EDOs de primer orden.

    Resuelve: dY/dt = F(t, Y),  Y(t0) = Y0
    donde Y es un vector de variables de estado.

    Parámetros:
        F  : función vectorial F(t, Y) → array
        t0 : tiempo inicial
        Y0 : vector de condiciones iniciales
        tf : tiempo final
        h  : tamaño de paso

    Retorna:
        dict con t (array de tiempos) e Y (matriz n_pasos × n_vars)
    """
    Y0 = np.array(Y0, dtype=float)
    t = np.arange(t0, tf + h * 1e-10, h)
    n = len(t)
    dim = len(Y0)

    Y = np.zeros((n, dim))
    Y[0] = Y0

    for i in range(n - 1):
        ti = t[i]
        yi = Y[i]

        k1 = h * np.array(F(ti, yi), dtype=float)
        k2 = h * np.array(F(ti + h / 2, yi + k1 / 2), dtype=float)
        k3 = h * np.array(F(ti + h / 2, yi + k2 / 2), dtype=float)
        k4 = h * np.array(F(ti + h, yi + k3), dtype=float)

        Y[i + 1] = yi + (k1 + 2 * k2 + 2 * k3 + k4) / 6

    return {
        "t": t, "Y": Y, "h": h, "pasos": n - 1,
        "dimensiones": dim, "metodo": "RK4 vectorial para sistemas",
    }
