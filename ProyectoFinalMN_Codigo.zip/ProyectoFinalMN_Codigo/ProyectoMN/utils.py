"""
PROYECTO J&R — Utilidades compartidas
Evaluador seguro de expresiones y helpers de tema.
"""

import numpy as np

# ── Namespace seguro para eval ────────────────────────────────────────────────
SAFE_NS: dict = {k: getattr(np, k) for k in dir(np) if not k.startswith("_")}
SAFE_NS.update({
    "sin": np.sin, "cos": np.cos, "tan": np.tan,
    "exp": np.exp, "log": np.log, "log10": np.log10, "log2": np.log2,
    "sqrt": np.sqrt, "abs": np.abs, "pi": np.pi, "e": np.e,
    "sinh": np.sinh, "cosh": np.cosh, "tanh": np.tanh,
    "arcsin": np.arcsin, "arccos": np.arccos, "arctan": np.arctan,
    "sign": np.sign, "floor": np.floor, "ceil": np.ceil,
})


def safe_eval_x(expr: str, x) -> float:
    """Evalúa f(x) de forma segura."""
    return eval(expr.strip(), {"__builtins__": {}}, {**SAFE_NS, "x": x})  # noqa: S307


def safe_eval_ty(expr: str, t, y) -> float:
    """Evalúa f(t, y) de forma segura para EDOs."""
    return eval(expr.strip(), {"__builtins__": {}}, {**SAFE_NS, "t": t, "y": y})  # noqa: S307


def make_f(expr: str):
    """Devuelve callable f(x) a partir de una expresión string."""
    def f(x):
        return safe_eval_x(expr, x)
    return f


def make_ode(expr: str):
    """Devuelve callable f(t, y) a partir de una expresión string."""
    def f(t, y):
        return safe_eval_ty(expr, t, y)
    return f
