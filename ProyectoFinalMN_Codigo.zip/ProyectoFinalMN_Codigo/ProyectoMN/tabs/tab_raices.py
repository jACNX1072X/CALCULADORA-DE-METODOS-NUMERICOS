"""
PROYECTO FINAL — Métodos Numéricos
Tab: Módulo 1 — Cálculo de Raíces

Métodos: Bisección, Newton-Raphson, Secante, Regula Falsi, Punto Fijo, SciPy brentq
Backend: metodos.py (biblioteca central del proyecto)
SymPy: derivada simbólica automática para Newton-Raphson
SciPy: brentq como método de referencia
"""

import traceback
import numpy as np
import sympy as sp
from scipy import optimize

from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QGridLayout,
    QPushButton, QLabel, QLineEdit, QComboBox,
    QGroupBox, QSplitter, QTableWidget, QTableWidgetItem,
    QTextEdit, QHeaderView, QSizePolicy, QScrollArea,
)
from PyQt6.QtCore import Qt
from PyQt6.QtGui import QFont

try:
    import matplotlib
    matplotlib.use("QtAgg")
    from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg as FigureCanvas
    from matplotlib.backends.backend_qtagg import NavigationToolbar2QT as NavigationToolbar
    from matplotlib.figure import Figure
    MATPLOTLIB_OK = True
except Exception:
    MATPLOTLIB_OK = False

from metodos import biseccion, newton_raphson, secante, regula_falsi, punto_fijo
from themes import get_theme
from utils import make_f, SAFE_NS


class TabRaices(QWidget):
    """
    Pestaña de Búsqueda de Raíces — Módulo 1.
    Implementa: Bisección, Newton-Raphson, Secante,
                Regula Falsi, Punto Fijo, SciPy brentq.
    """

    def __init__(self, historial_fn=None, parent=None):
        super().__init__(parent)
        self._historial_fn = historial_fn
        self._resultado = None
        self._init_ui()

    # ── Construcción UI ───────────────────────────────────────────────────────

    def _init_ui(self):
        root = QHBoxLayout(self)
        root.setContentsMargins(4, 4, 4, 4)

        splitter = QSplitter(Qt.Orientation.Horizontal)

        # ── Panel izquierdo (scroll) ──────────────────────────────────────────
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(scroll.Shape.NoFrame)
        scroll.setSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Expanding)

        left_inner = QWidget()
        ll = QVBoxLayout(left_inner)
        ll.setSpacing(10)
        ll.setContentsMargins(8, 8, 8, 8)

        # ── Función f(x) ──────────────────────────────────────────────────────
        grp_fn = QGroupBox("1. Función Matemática")
        grp_fn.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Preferred)
        gf = QGridLayout(grp_fn)
        gf.setColumnStretch(0, 0)
        gf.setColumnStretch(1, 1)
        gf.setVerticalSpacing(8)

        lbl_fx = QLabel("f(x) =")
        lbl_fx.setWordWrap(True)
        lbl_fx.setSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Fixed)
        gf.addWidget(lbl_fx, 0, 0)

        self.le_func = QLineEdit("cos(x) - x")
        self.le_func.setMinimumHeight(34)
        self.le_func.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        self.le_func.setPlaceholderText("ej: cos(x) - x  |  x**3 - 2*x - 5")
        gf.addWidget(self.le_func, 0, 1)

        lbl_gx = QLabel("g(x) =\n[Punto Fijo]")
        lbl_gx.setWordWrap(True)
        lbl_gx.setSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Fixed)
        gf.addWidget(lbl_gx, 1, 0)

        self.le_gx = QLineEdit("cos(x)")
        self.le_gx.setMinimumHeight(34)
        self.le_gx.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        self.le_gx.setPlaceholderText("función de iteración g(x)")
        gf.addWidget(self.le_gx, 1, 1)

        self.lbl_deriv = QLabel("f'(x) = (automático con SymPy)")
        self.lbl_deriv.setWordWrap(True)
        self.lbl_deriv.setSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Fixed)
        self.lbl_deriv.setStyleSheet("color: #43e97b; font-style: italic; font-size: 11px;")
        gf.addWidget(self.lbl_deriv, 2, 0, 1, 2)

        btn_sym = QPushButton("🔣  Calcular f'(x) con SymPy")
        btn_sym.setMinimumHeight(36)
        btn_sym.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        btn_sym.clicked.connect(self._calcular_derivada_simbolica)
        gf.addWidget(btn_sym, 3, 0, 1, 2)
        ll.addWidget(grp_fn)

        # ── Parámetros Iniciales ──────────────────────────────────────────────
        grp_par = QGroupBox("2. Parámetros Iniciales")
        grp_par.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Preferred)
        gp = QGridLayout(grp_par)
        gp.setColumnStretch(0, 0)
        gp.setColumnStretch(1, 1)
        gp.setVerticalSpacing(8)

        params = [
            ("a  /  x₀ =", "0",   "extremo izquierdo o punto inicial"),
            ("b  /  x₁ =", "1",   "extremo derecho o segundo punto"),
        ]
        self.le_a = None
        self.le_b = None
        for row, (lbl_txt, val, ph) in enumerate(params):
            lbl = QLabel(lbl_txt)
            lbl.setWordWrap(True)
            lbl.setSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Fixed)
            gp.addWidget(lbl, row, 0)
            le = QLineEdit(val)
            le.setMinimumHeight(34)
            le.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
            le.setPlaceholderText(ph)
            gp.addWidget(le, row, 1)
            if row == 0:
                self.le_a = le
            else:
                self.le_b = le
        ll.addWidget(grp_par)

        # ── Configuración ─────────────────────────────────────────────────────
        grp_cfg = QGroupBox("3. Configuración")
        grp_cfg.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Preferred)
        gc = QGridLayout(grp_cfg)
        gc.setColumnStretch(0, 0)
        gc.setColumnStretch(1, 1)
        gc.setVerticalSpacing(8)

        lbl_tol = QLabel("Tolerancia =")
        lbl_tol.setWordWrap(True)
        lbl_tol.setSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Fixed)
        gc.addWidget(lbl_tol, 0, 0)
        self.le_tol = QLineEdit("1e-8")
        self.le_tol.setMinimumHeight(34)
        self.le_tol.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        self.le_tol.setPlaceholderText("ej: 1e-8")
        gc.addWidget(self.le_tol, 0, 1)

        lbl_iter = QLabel("Máx. iteraciones =")
        lbl_iter.setWordWrap(True)
        lbl_iter.setSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Fixed)
        gc.addWidget(lbl_iter, 1, 0)
        self.le_iter = QLineEdit("100")
        self.le_iter.setMinimumHeight(34)
        self.le_iter.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        gc.addWidget(self.le_iter, 1, 1)
        ll.addWidget(grp_cfg)

        # ── Método ────────────────────────────────────────────────────────────
        grp_met = QGroupBox("4. Método")
        grp_met.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Preferred)
        gm = QVBoxLayout(grp_met)
        self.cb_metodo = QComboBox()
        self.cb_metodo.setMinimumHeight(34)
        self.cb_metodo.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        self.cb_metodo.addItems([
            "Bisección",
            "Newton-Raphson (SymPy)",
            "Secante",
            "Regula Falsi",
            "Punto Fijo",
            "SciPy brentq (referencia)",
        ])
        gm.addWidget(self.cb_metodo)
        ll.addWidget(grp_met)

        # ── Acciones ──────────────────────────────────────────────────────────
        grp_acc = QGroupBox("5. Acciones")
        grp_acc.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Preferred)
        ga = QVBoxLayout(grp_acc)

        btn_calc = QPushButton("▶  Calcular Raíz")
        btn_calc.setMinimumHeight(36)
        btn_calc.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        btn_calc.clicked.connect(self._calcular)

        btn_limpiar = QPushButton("🗑  Limpiar")
        btn_limpiar.setMinimumHeight(36)
        btn_limpiar.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        btn_limpiar.clicked.connect(self._limpiar)

        bh = QHBoxLayout()
        bh.addWidget(btn_calc)
        bh.addWidget(btn_limpiar)
        ga.addLayout(bh)

        lbl_res = QLabel("Resultado:")
        lbl_res.setWordWrap(True)
        lbl_res.setSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Fixed)
        ga.addWidget(lbl_res)

        self.txt_result = QTextEdit()
        self.txt_result.setReadOnly(True)
        self.txt_result.setFont(QFont("Courier New", 9))
        self.txt_result.setMinimumHeight(120)
        ga.addWidget(self.txt_result)
        ll.addWidget(grp_acc)

        ll.addStretch()
        scroll.setWidget(left_inner)
        splitter.addWidget(scroll)

        # ── Panel derecho ─────────────────────────────────────────────────────
        right = QWidget()
        rl = QVBoxLayout(right)

        lbl_tabla = QLabel("Tabla de iteraciones:")
        lbl_tabla.setWordWrap(True)
        lbl_tabla.setSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Fixed)
        rl.addWidget(lbl_tabla)

        self.tabla = QTableWidget(0, 5)
        self.tabla.setHorizontalHeaderLabels(
            ["Iter", "a / x₀", "b / x₁", "c / x_nuevo", "Error"]
        )
        self.tabla.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        self.tabla.setMinimumHeight(180)
        rl.addWidget(self.tabla)

        if MATPLOTLIB_OK:
            self.fig = Figure(figsize=(6, 4))
            self.canvas = FigureCanvas(self.fig)
            self.toolbar = NavigationToolbar(self.canvas, right)
            rl.addWidget(self.toolbar)
            rl.addWidget(self.canvas)
        else:
            rl.addWidget(QLabel("⚠ Matplotlib no disponible"))

        splitter.addWidget(right)
        splitter.setStretchFactor(0, 2)
        splitter.setStretchFactor(1, 3)
        root.addWidget(splitter)

    # ── SymPy ─────────────────────────────────────────────────────────────────

    def _calcular_derivada_simbolica(self):
        try:
            expr_str = self.le_func.text().strip()
            x = sp.Symbol("x")
            expr = sp.sympify(expr_str)
            deriv = sp.simplify(sp.diff(expr, x))
            self.lbl_deriv.setText(f"f'(x) = {deriv}  [SymPy]")
            self._sympy_deriv = str(deriv)
        except Exception as e:
            self.lbl_deriv.setText(f"⚠ Error SymPy: {e}")
            self._sympy_deriv = None

    def _get_sympy_df(self):
        x_sym = sp.Symbol("x")
        expr = sp.sympify(self.le_func.text().strip())
        deriv = sp.diff(expr, x_sym)
        return sp.lambdify(x_sym, deriv, modules=["numpy"])

    # ── Cálculo principal ─────────────────────────────────────────────────────

    def _calcular(self):
        try:
            f = make_f(self.le_func.text())
            a = float(self.le_a.text())
            b = float(self.le_b.text())
            tol = float(self.le_tol.text())
            max_it = int(self.le_iter.text())
            metodo = self.cb_metodo.currentText()

            if "Bisección" in metodo:
                res = biseccion(f, a, b, tol=tol, max_iter=max_it)
                self._mostrar_resultado_dict(res, metodo)
                self._llenar_tabla_dict(res["tabla"], ["iteracion", "a", "b", "c", "error"])
                self._graficar(f, a, b, res["raiz"])

            elif "Newton-Raphson" in metodo:
                df = self._get_sympy_df()
                res = newton_raphson(f, df, x0=a, tol=tol, max_iter=max_it)
                self._mostrar_resultado_dict(res, metodo)
                self._llenar_tabla_dict(res["tabla"], ["iteracion", "x", "x_nuevo", "error"])
                self._graficar(f, a - 2, b + 2, res["raiz"])

            elif "Secante" in metodo:
                res = secante(f, a, b, tol=tol, max_iter=max_it)
                self._mostrar_resultado_dict(res, metodo)
                self._llenar_tabla_dict(res["tabla"], ["iteracion", "x0", "x1", "x2", "error"])
                self._graficar(f, a - 1, b + 1, res["raiz"])

            elif "Regula Falsi" in metodo:
                res = regula_falsi(f, a, b, tol=tol, max_iter=max_it)
                self._mostrar_resultado_dict(res, metodo)
                self._llenar_tabla_dict(res["tabla"], ["iteracion", "a", "b", "c", "error"])
                self._graficar(f, a, b, res["raiz"])

            elif "Punto Fijo" in metodo:
                g = make_f(self.le_gx.text())
                res = punto_fijo(g, x0=a, tol=tol, max_iter=max_it)
                self._mostrar_resultado_dict(res, metodo)
                self._llenar_tabla_dict(res["tabla"], ["iteracion", "x", "g(x)", "error"])
                self._graficar(f, a - 1, b + 1, res["raiz"])

            elif "SciPy" in metodo:
                raiz = optimize.brentq(f, a, b, xtol=tol, maxiter=max_it)
                self._resultado = raiz
                self.txt_result.setPlainText(
                    f"  Método     : SciPy brentq (referencia)\n"
                    f"  Raíz       = {raiz:.12f}\n"
                    f"  f(raíz)    = {f(raiz):.4e}"
                )
                self.tabla.setRowCount(0)
                self._graficar(f, a, b, raiz)

            if self._historial_fn and self._resultado is not None:
                self._historial_fn(
                    "Raíces", metodo,
                    f"raíz ≈ {self._resultado:.8f}"
                )

        except Exception:
            self.txt_result.setPlainText(f"⚠ Error:\n{traceback.format_exc()}")

    def _mostrar_resultado_dict(self, res: dict, metodo: str):
        self._resultado = res.get("raiz")
        conv = "✅ Convergió" if res.get("convergencia") else "⚠ No convergió"
        lines = [
            f"  Método     : {metodo}",
            f"  Raíz       = {res.get('raiz', '?'):.12f}",
        ]
        if "f(raiz)" in res:
            lines.append(f"  f(raíz)    = {res['f(raiz)']:.4e}")
        if "error_final" in res:
            lines.append(f"  Error final: {res['error_final']:.4e}")
        if "iteraciones" in res:
            lines.append(f"  Iteraciones: {res['iteraciones']}")
        lines.append(f"  Estado     : {conv}")
        self.txt_result.setPlainText("\n".join(lines))

    def _llenar_tabla_dict(self, tabla: list, cols: list):
        self.tabla.setRowCount(0)
        self.tabla.setColumnCount(len(cols))
        self.tabla.setHorizontalHeaderLabels(cols)
        for row_data in tabla:
            r = self.tabla.rowCount()
            self.tabla.insertRow(r)
            for c, key in enumerate(cols):
                v = row_data.get(key, "—")
                if isinstance(v, float):
                    txt = f"{v:.8f}"
                elif v is None:
                    txt = "—"
                else:
                    txt = str(v)
                self.tabla.setItem(r, c, QTableWidgetItem(txt))

    def _limpiar(self):
        self.txt_result.clear()
        self.tabla.setRowCount(0)
        self._resultado = None
        if MATPLOTLIB_OK:
            self.fig.clear()
            self.canvas.draw()

    def _graficar(self, f, a: float, b: float, raiz: float):
        if not MATPLOTLIB_OK:
            return
        t = get_theme()
        self.fig.clear()
        self.fig.patch.set_facecolor(t["plot_bg"])
        ax = self.fig.add_subplot(111)
        ax.set_facecolor(t["plot_bg"])

        margen = max(abs(b - a) * 0.3, 0.5)
        x = np.linspace(a - margen, b + margen, 600)
        try:
            y = np.array([f(xi) for xi in x])
        except Exception:
            return

        ax.plot(x, y, color=t["accent"], linewidth=2, label="f(x)")
        ax.axhline(0, color=t["plot_fg"], linewidth=0.8, linestyle="--", alpha=0.5)
        ax.axvline(raiz, color=t["accent2"], linewidth=1.5, linestyle=":",
                   label=f"raíz ≈ {raiz:.6f}")
        ax.scatter([raiz], [f(raiz)], color=t["accent3"], zorder=5, s=80)
        ax.set_xlabel("x", color=t["plot_fg"])
        ax.set_ylabel("f(x)", color=t["plot_fg"])
        ax.set_title(f"f(x) = {self.le_func.text()}", color=t["plot_fg"], fontsize=10)
        ax.tick_params(colors=t["plot_fg"])
        for sp_ in ax.spines.values():
            sp_.set_edgecolor(t["border"])
        ax.grid(True, color=t["plot_grid"], alpha=0.4)
        ax.legend(fontsize=8, facecolor=t["bg_card"], labelcolor=t["text_primary"])
        self.fig.tight_layout()
        self.canvas.draw()

    def apply_theme(self):
        if MATPLOTLIB_OK and self._resultado is not None:
            try:
                f = make_f(self.le_func.text())
                a, b = float(self.le_a.text()), float(self.le_b.text())
                self._graficar(f, a, b, self._resultado)
            except Exception:
                pass
