"""
PROYECTO FINAL — Métodos Numéricos
Tab: Módulo 5 — Ecuaciones Diferenciales Ordinarias (EDO)

Métodos: Euler, Euler Mejorado (Heun), RK4, RK45 Adaptativo, SciPy solve_ivp
Backend: metodos.py (biblioteca central)
SciPy: solve_ivp como referencia
SymPy: solución simbólica cuando es posible
"""

import traceback
import numpy as np
import sympy as sp
from scipy.integrate import solve_ivp

from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QGridLayout,
    QLabel, QLineEdit, QPushButton,
    QGroupBox, QTextEdit,
    QTableWidget, QTableWidgetItem, QHeaderView,
    QCheckBox, QSplitter, QSizePolicy, QScrollArea, QFrame,
)
from PyQt6.QtCore import Qt
from PyQt6.QtGui import QFont

try:
    import matplotlib
    matplotlib.use("QtAgg")
    from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg as FigureCanvas
    from matplotlib.backends.backend_qtagg import NavigationToolbar2QT as NavigationToolbar
    from matplotlib.figure import Figure
    MATPLOTLIB_OK = True
except Exception:
    MATPLOTLIB_OK = False

from metodos import euler, euler_mejorado, runge_kutta_4
from themes import get_theme
from utils import make_ode, SAFE_NS


# ── RK45 Adaptativo (Dormand-Prince) ─────────────────────────────────────────

def rk45_adaptativo(f, t0, y0, tf, h0=0.1, tol=1e-6):
    """RK4-5 adaptativo (Dormand-Prince). Implementado localmente."""
    c2, c3, c4, c5 = 1/5, 3/10, 4/5, 8/9
    a21 = 1/5
    a31, a32 = 3/40, 9/40
    a41, a42, a43 = 44/45, -56/15, 32/9
    a51, a52, a53, a54 = 19372/6561, -25360/2187, 64448/6561, -212/729
    a61, a62, a63, a64, a65 = 9017/3168, -355/33, 46732/5247, 49/176, -5103/18656
    b1, b3, b4, b5, b6 = 35/384, 500/1113, 125/192, -2187/6784, 11/84
    e1, e3, e4, e5, e6, e7 = 71/57600, -71/16695, 71/1920, -17253/339200, 22/525, -1/40

    t_list, y_list = [t0], [y0]
    t, y, h = t0, y0, h0

    while t < tf:
        if t + h > tf:
            h = tf - t
        k1 = f(t, y)
        k2 = f(t + c2*h, y + h*a21*k1)
        k3 = f(t + c3*h, y + h*(a31*k1 + a32*k2))
        k4 = f(t + c4*h, y + h*(a41*k1 + a42*k2 + a43*k3))
        k5 = f(t + c5*h, y + h*(a51*k1 + a52*k2 + a53*k3 + a54*k4))
        k6 = f(t + h,    y + h*(a61*k1 + a62*k2 + a63*k3 + a64*k4 + a65*k5))
        y_new = y + h*(b1*k1 + b3*k3 + b4*k4 + b5*k5 + b6*k6)
        k7 = f(t + h, y_new)
        err = h * abs(e1*k1 + e3*k3 + e4*k4 + e5*k5 + e6*k6 + e7*k7)
        if err == 0 or err <= tol:
            t += h
            y = y_new
            t_list.append(t)
            y_list.append(y)
        scale = 0.9 * (tol / (err + 1e-30))**0.2
        h = min(h * scale, 5.0)

    return np.array(t_list), np.array(y_list)


# ══════════════════════════════════════════════════════════════════════════════
# WIDGET
# ══════════════════════════════════════════════════════════════════════════════

class TabEDO(QWidget):
    """
    Pestaña de Ecuaciones Diferenciales Ordinarias — Módulo 5.
    Panel izquierdo con QScrollArea para legibilidad máxima.
    """

    def __init__(self, historial_fn=None, parent=None):
        super().__init__(parent)
        self._historial_fn = historial_fn
        self._resultados = {}
        self._fig_cache = None
        self._build_ui()

    def _build_ui(self):
        root = QHBoxLayout(self)
        root.setContentsMargins(4, 4, 4, 4)

        splitter = QSplitter(Qt.Orientation.Horizontal)

        # ── Panel izquierdo con QScrollArea ───────────────────────────────────
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.Shape.NoFrame)
        scroll.setSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Expanding)

        left_inner = QWidget()
        ll = QVBoxLayout(left_inner)
        ll.setSpacing(10)
        ll.setContentsMargins(8, 8, 8, 8)

        # 1. Ecuación
        grp_eq = QGroupBox("1. Ecuación  dy/dt = f(t, y)")
        grp_eq.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Preferred)
        ge = QGridLayout(grp_eq)
        ge.setColumnStretch(0, 0)
        ge.setColumnStretch(1, 1)
        ge.setVerticalSpacing(8)

        lbl_eq = QLabel("f(t, y) =")
        lbl_eq.setWordWrap(True)
        lbl_eq.setSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Fixed)
        ge.addWidget(lbl_eq, 0, 0)
        self.le_eq = QLineEdit("-2*y + t")
        self.le_eq.setMinimumHeight(34)
        self.le_eq.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        self.le_eq.setPlaceholderText("ej: -2*y + t  |  y*(1-y)  |  -y + sin(t)")
        ge.addWidget(self.le_eq, 0, 1)
        ll.addWidget(grp_eq)

        # 2. Condiciones Iniciales
        grp_ci = QGroupBox("2. Condiciones Iniciales")
        grp_ci.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Preferred)
        gci = QGridLayout(grp_ci)
        gci.setColumnStretch(0, 0)
        gci.setColumnStretch(1, 1)
        gci.setVerticalSpacing(8)

        self.le_params = {}
        ci_params = [
            ("t₀ =", "t₀", "0",   "tiempo inicial"),
            ("y₀ =", "y₀", "1",   "condición inicial y(t₀)"),
        ]
        for row, (lbl_txt, key, val, ph) in enumerate(ci_params):
            lbl = QLabel(lbl_txt)
            lbl.setWordWrap(True)
            lbl.setSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Fixed)
            gci.addWidget(lbl, row, 0)
            le = QLineEdit(val)
            le.setMinimumHeight(34)
            le.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
            le.setPlaceholderText(ph)
            gci.addWidget(le, row, 1)
            self.le_params[key] = le
        ll.addWidget(grp_ci)

        # 3. Dominio
        grp_dom = QGroupBox("3. Dominio y Paso")
        grp_dom.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Preferred)
        gdom = QGridLayout(grp_dom)
        gdom.setColumnStretch(0, 0)
        gdom.setColumnStretch(1, 1)
        gdom.setVerticalSpacing(8)

        dom_params = [
            ("t final =", "t_final", "5",   "tiempo final"),
            ("Paso h =",  "Paso h",  "0.1", "tamaño de paso (ej: 0.1)"),
        ]
        for row, (lbl_txt, key, val, ph) in enumerate(dom_params):
            lbl = QLabel(lbl_txt)
            lbl.setWordWrap(True)
            lbl.setSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Fixed)
            gdom.addWidget(lbl, row, 0)
            le = QLineEdit(val)
            le.setMinimumHeight(34)
            le.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
            le.setPlaceholderText(ph)
            gdom.addWidget(le, row, 1)
            self.le_params[key] = le
        ll.addWidget(grp_dom)

        # 4. Solución Exacta
        grp_ex = QGroupBox("4. Solución Exacta (opcional)")
        grp_ex.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Preferred)
        gex = QGridLayout(grp_ex)
        gex.setColumnStretch(0, 0)
        gex.setColumnStretch(1, 1)
        gex.setVerticalSpacing(8)

        lbl_ex = QLabel("y(t) =")
        lbl_ex.setWordWrap(True)
        lbl_ex.setSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Fixed)
        gex.addWidget(lbl_ex, 0, 0)
        self.le_exact = QLineEdit("(t/2) - (1/4) + (5/4)*exp(-2*t)")
        self.le_exact.setMinimumHeight(34)
        self.le_exact.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        self.le_exact.setPlaceholderText("dejar vacío si no se conoce")
        gex.addWidget(self.le_exact, 0, 1)

        self.lbl_sym = QLabel("—")
        self.lbl_sym.setWordWrap(True)
        self.lbl_sym.setSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Preferred)
        self.lbl_sym.setStyleSheet("color: #43e97b; font-style: italic; font-size: 10px;")
        gex.addWidget(self.lbl_sym, 1, 0, 1, 2)

        btn_sym = QPushButton("🔣  Resolver con SymPy (EDO lineal)")
        btn_sym.setMinimumHeight(36)
        btn_sym.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        btn_sym.clicked.connect(self._resolver_simbolico)
        gex.addWidget(btn_sym, 2, 0, 1, 2)
        ll.addWidget(grp_ex)

        # 5. Métodos
        grp_met = QGroupBox("5. Métodos a ejecutar")
        grp_met.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Preferred)
        gm = QVBoxLayout(grp_met)
        gm.setSpacing(6)

        self.chk = {}
        metodos = [
            "Euler",
            "Euler Mejorado (Heun)",
            "RK4",
            "RK45 Adaptativo",
            "SciPy solve_ivp",
        ]
        for m in metodos:
            cb = QCheckBox(m)
            cb.setChecked(True)
            cb.setMinimumHeight(34)
            cb.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
            cb.setStyleSheet("QCheckBox { font-size: 13px; padding: 4px; }")
            gm.addWidget(cb)
            self.chk[m] = cb
        ll.addWidget(grp_met)

        # 6. Acciones
        grp_acc = QGroupBox("6. Acciones")
        grp_acc.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Preferred)
        ga = QVBoxLayout(grp_acc)

        btn_solve = QPushButton("▶  Resolver EDO")
        btn_solve.setMinimumHeight(36)
        btn_solve.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        btn_solve.clicked.connect(self._resolver)

        btn_err = QPushButton("📉  Gráfica de Error")
        btn_err.setMinimumHeight(36)
        btn_err.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        btn_err.clicked.connect(self._graficar_error)

        bh = QHBoxLayout()
        bh.addWidget(btn_solve)
        bh.addWidget(btn_err)
        ga.addLayout(bh)

        lbl_res = QLabel("Resultados:")
        lbl_res.setWordWrap(True)
        lbl_res.setSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Fixed)
        ga.addWidget(lbl_res)

        self.txt_result = QTextEdit()
        self.txt_result.setReadOnly(True)
        self.txt_result.setFont(QFont("Courier New", 9))
        self.txt_result.setMinimumHeight(130)
        ga.addWidget(self.txt_result)
        ll.addWidget(grp_acc)

        ll.addStretch()
        scroll.setWidget(left_inner)
        splitter.addWidget(scroll)

        # ── Panel derecho ─────────────────────────────────────────────────────
        right = QWidget()
        rl = QVBoxLayout(right)

        lbl_tabla = QLabel("Tabla de valores:")
        lbl_tabla.setWordWrap(True)
        lbl_tabla.setSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Fixed)
        rl.addWidget(lbl_tabla)

        self.tabla = QTableWidget(0, 5)
        self.tabla.setHorizontalHeaderLabels(["t", "Euler", "Heun", "RK4", "Exacta"])
        self.tabla.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        self.tabla.setMinimumHeight(180)
        rl.addWidget(self.tabla)

        if MATPLOTLIB_OK:
            self.fig = Figure(figsize=(6, 5))
            self.canvas = FigureCanvas(self.fig)
            self.toolbar = NavigationToolbar(self.canvas, right)
            rl.addWidget(self.toolbar)
            rl.addWidget(self.canvas)

        splitter.addWidget(right)
        splitter.setStretchFactor(0, 2)
        splitter.setStretchFactor(1, 3)
        root.addWidget(splitter)

    # ── SymPy ──────────────────────────────────────────────────────────────────

    def _resolver_simbolico(self):
        try:
            t_s = sp.Symbol("t")
            y_s = sp.Function("y")
            eq_str = self.le_eq.text().strip()
            ode = sp.Eq(
                y_s(t_s).diff(t_s),
                sp.sympify(eq_str.replace("y", "y(t)"))
            )
            sol = sp.dsolve(ode, y_s(t_s))
            self.lbl_sym.setText(f"y(t) = {sol.rhs}")
        except Exception as e:
            self.lbl_sym.setText(f"⚠ SymPy no pudo resolver: {e}")

    # ── Parámetros ────────────────────────────────────────────────────────────

    def _params(self):
        return (
            float(self.le_params["t₀"].text()),
            float(self.le_params["y₀"].text()),
            float(self.le_params["t_final"].text()),
            float(self.le_params["Paso h"].text()),
        )

    def _get_f(self):
        return make_ode(self.le_eq.text())

    def _get_exact(self):
        expr = self.le_exact.text().strip()
        if not expr:
            return None
        try:
            ns = {**SAFE_NS}
            return lambda t: eval(expr, {"__builtins__": {}}, {**ns, "t": t})
        except Exception:
            return None

    # ── Cálculo ────────────────────────────────────────────────────────────────

    def _resolver(self):
        try:
            f = self._get_f()
            t0, y0, tf, h = self._params()
            res = {}

            if self.chk["Euler"].isChecked():
                r = euler(f, t0, y0, tf, h)
                res["Euler"] = (r["t"], r["y"])

            if self.chk["Euler Mejorado (Heun)"].isChecked():
                r = euler_mejorado(f, t0, y0, tf, h)
                res["Heun"] = (r["t"], r["y"])

            if self.chk["RK4"].isChecked():
                r = runge_kutta_4(f, t0, y0, tf, h)
                res["RK4"] = (r["t"], r["y"])

            if self.chk["RK45 Adaptativo"].isChecked():
                t_arr, y_arr = rk45_adaptativo(f, t0, y0, tf, h0=h)
                res["RK45"] = (t_arr, y_arr)

            if self.chk["SciPy solve_ivp"].isChecked():
                sol = solve_ivp(f, [t0, tf], [y0], method="RK45",
                                max_step=h, dense_output=False)
                res["SciPy RK45"] = (sol.t, sol.y[0])

            self._resultados = res
            exact_fn = self._get_exact()

            # Tabla
            t_ref = res.get("RK4", list(res.values())[0])[0]
            step_show = max(1, len(t_ref) // 30)
            t_show = t_ref[::step_show]

            def interp_safe(key, t_vals):
                if key not in res:
                    return [None] * len(t_vals)
                t_k, y_k = res[key]
                return np.interp(t_vals, t_k, y_k)

            self.tabla.setRowCount(len(t_show))
            for i, tv in enumerate(t_show):
                self.tabla.setItem(i, 0, QTableWidgetItem(f"{tv:.4f}"))
                for j, key in enumerate(["Euler", "Heun", "RK4"]):
                    v = interp_safe(key, [tv])[0]
                    self.tabla.setItem(i, j + 1, QTableWidgetItem(
                        f"{v:.6f}" if v is not None else "—"))
                v_ex = exact_fn(tv) if exact_fn else "—"
                self.tabla.setItem(i, 4, QTableWidgetItem(
                    f"{v_ex:.6f}" if isinstance(v_ex, float) else v_ex))

            # Texto
            lines = [
                f"  dy/dt = {self.le_eq.text()}",
                f"  t∈[{t0},{tf}]  h={h}  y(t₀)={y0}", ""
            ]
            for key, (t_k, y_k) in res.items():
                y_f = y_k[-1]
                ex_str = f"  err={abs(y_f - exact_fn(t_k[-1])):.2e}" if exact_fn else ""
                lines.append(f"  {key:<22} y(tf) = {y_f:.8f}{ex_str}")
            self.txt_result.setPlainText("\n".join(lines))

            self._graficar_solucion(exact_fn)

            if self._historial_fn:
                first = list(res.values())[0][1][-1]
                self._historial_fn("EDO", self.le_eq.text(), f"y(tf) ≈ {first:.6f}")

        except Exception:
            self.txt_result.setPlainText(f"⚠ Error:\n{traceback.format_exc()}")

    # ── Gráficas ──────────────────────────────────────────────────────────────

    def _graficar_solucion(self, exact_fn=None):
        if not MATPLOTLIB_OK:
            return
        t_colors = {
            "Euler": "#e74c3c", "Heun": "#e67e22", "RK4": "#2980b9",
            "RK45": "#8e44ad", "SciPy RK45": "#1abc9c",
        }
        t_styles = {
            "Euler": ":", "Heun": "--", "RK4": "-",
            "RK45": "-", "SciPy RK45": "-.",
        }
        t = get_theme()
        self.fig.clear()
        self.fig.patch.set_facecolor(t["plot_bg"])
        ax = self.fig.add_subplot(111)
        ax.set_facecolor(t["plot_bg"])

        for key, (t_k, y_k) in self._resultados.items():
            ax.plot(t_k, y_k, color=t_colors.get(key, t["accent"]),
                    linestyle=t_styles.get(key, "-"), linewidth=1.8,
                    label=key, alpha=0.9)

        if exact_fn:
            t_ref = list(self._resultados.values())[0][0]
            t_fine = np.linspace(t_ref[0], t_ref[-1], 800)
            ax.plot(t_fine, exact_fn(t_fine), "k-", linewidth=2.5,
                    label="Exacta", zorder=10)

        ax.set_xlabel("t", color=t["plot_fg"])
        ax.set_ylabel("y(t)", color=t["plot_fg"])
        ax.set_title(f"dy/dt = {self.le_eq.text()}", color=t["plot_fg"], fontsize=10)
        ax.tick_params(colors=t["plot_fg"])
        for sp_ in ax.spines.values():
            sp_.set_edgecolor(t["border"])
        ax.grid(True, color=t["plot_grid"], alpha=0.3)
        ax.legend(fontsize=8, facecolor=t["bg_card"], labelcolor=t["text_primary"])
        self.fig.tight_layout()
        self.canvas.draw()
        self._fig_cache = self.fig

    def _graficar_error(self):
        exact_fn = self._get_exact()
        if not exact_fn or not self._resultados:
            self.txt_result.setPlainText(
                "Se requiere solución exacta y resultados calculados."
            )
            return
        t = get_theme()
        t_colors = {
            "Euler": "#e74c3c", "Heun": "#e67e22", "RK4": "#2980b9",
            "RK45": "#8e44ad", "SciPy RK45": "#1abc9c",
        }
        self.fig.clear()
        self.fig.patch.set_facecolor(t["plot_bg"])
        ax = self.fig.add_subplot(111)
        ax.set_facecolor(t["plot_bg"])

        for key, (t_k, y_k) in self._resultados.items():
            if key == "SciPy RK45":
                continue
            err = np.abs(y_k - exact_fn(t_k))
            ax.semilogy(t_k, err + 1e-16,
                        color=t_colors.get(key, t["accent"]),
                        linewidth=1.8, label=key)

        ax.set_xlabel("t", color=t["plot_fg"])
        ax.set_ylabel("|Error global|", color=t["plot_fg"])
        ax.set_title("Error vs solución exacta (escala log)", color=t["plot_fg"], fontsize=10)
        ax.tick_params(colors=t["plot_fg"])
        for sp_ in ax.spines.values():
            sp_.set_edgecolor(t["border"])
        ax.grid(True, color=t["plot_grid"], alpha=0.3, which="both")
        ax.legend(fontsize=8, facecolor=t["bg_card"], labelcolor=t["text_primary"])
        self.fig.tight_layout()
        self.canvas.draw()

    def get_figure(self):
        return self._fig_cache if self._fig_cache else self.fig

    def apply_theme(self):
        if MATPLOTLIB_OK and self._resultados:
            self._graficar_solucion(self._get_exact())
