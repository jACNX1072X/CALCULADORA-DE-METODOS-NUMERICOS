"""
PROYECTO FINAL — Métodos Numéricos
Tab: Módulo 2 — Interpolación y Ajuste de Curvas

Métodos: Lagrange, Newton (Dif. Divididas), Spline Cúbico (SciPy),
         Mínimos Cuadrados, Todos (comparación)
Backend: metodos.py (biblioteca central)
SymPy: muestra el polinomio interpolante en forma simbólica
"""

import traceback
import numpy as np
import sympy as sp
from scipy.interpolate import CubicSpline

from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QGridLayout,
    QPushButton, QLabel, QLineEdit, QComboBox,
    QGroupBox, QSplitter, QTableWidget, QTableWidgetItem,
    QTextEdit, QHeaderView, QDoubleSpinBox, QSizePolicy, QScrollArea,
)
from PyQt6.QtCore import Qt
from PyQt6.QtGui import QFont

try:
    import matplotlib
    matplotlib.use("QtAgg")
    from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg as FigureCanvas
    from matplotlib.backends.backend_qtagg import NavigationToolbar2QT as NavigationToolbar
    from matplotlib.figure import Figure
    MATPLOTLIB_OK = True
except Exception:
    MATPLOTLIB_OK = False

from metodos import lagrange, diferencias_divididas, newton_interpolacion
from themes import get_theme


class TabInterpolacion(QWidget):
    """
    Pestaña de Interpolación — Módulo 2.
    Implementa: Lagrange, Newton DD, Spline Cúbico, Mínimos Cuadrados.
    SymPy genera el polinomio simbólico de Newton.
    """

    def __init__(self, historial_fn=None, parent=None):
        super().__init__(parent)
        self._historial_fn = historial_fn
        self._last_xs = None
        self._last_ys = None
        self._init_ui()

    def _init_ui(self):
        root = QHBoxLayout(self)
        root.setContentsMargins(4, 4, 4, 4)

        splitter = QSplitter(Qt.Orientation.Horizontal)

        # ── Panel izquierdo (scroll) ──────────────────────────────────────────
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(scroll.Shape.NoFrame)
        scroll.setSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Expanding)

        left_inner = QWidget()
        ll = QVBoxLayout(left_inner)
        ll.setSpacing(10)
        ll.setContentsMargins(8, 8, 8, 8)

        # Datos
        grp_dat = QGroupBox("Datos (x e y separados por comas)")
        grp_dat.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Preferred)
        gd = QGridLayout(grp_dat)
        gd.setColumnStretch(0, 0)
        gd.setColumnStretch(1, 1)
        gd.setVerticalSpacing(8)

        for row, (lbl_txt, attr, val, ph) in enumerate([
            ("x =",        "le_x",     "0, 1, 2, 3, 4",              "nodos x separados por comas"),
            ("y =",        "le_y",     "1, 2.718, 7.389, 20.086, 54.598", "valores y"),
            ("x evaluar =","le_xeval", "2.5",                         "punto a interpolar"),
        ]):
            lbl = QLabel(lbl_txt)
            lbl.setWordWrap(True)
            lbl.setSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Fixed)
            gd.addWidget(lbl, row, 0)
            le = QLineEdit(val)
            le.setMinimumHeight(34)
            le.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
            le.setPlaceholderText(ph)
            gd.addWidget(le, row, 1)
            setattr(self, attr, le)
        ll.addWidget(grp_dat)

        # Método
        grp_met = QGroupBox("Método de Interpolación")
        grp_met.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Preferred)
        gm = QVBoxLayout(grp_met)

        self.cb_metodo = QComboBox()
        self.cb_metodo.setMinimumHeight(34)
        self.cb_metodo.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        self.cb_metodo.addItems([
            "Lagrange",
            "Newton (Dif. Divididas)",
            "Spline Cúbico (SciPy)",
            "Mínimos Cuadrados",
            "Todos (comparación)",
        ])
        gm.addWidget(self.cb_metodo)

        grado_h = QHBoxLayout()
        lbl_gr = QLabel("Grado MC:")
        lbl_gr.setWordWrap(True)
        lbl_gr.setSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Fixed)
        grado_h.addWidget(lbl_gr)
        self.sp_grado = QDoubleSpinBox()
        self.sp_grado.setMinimumHeight(34)
        self.sp_grado.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        self.sp_grado.setRange(1, 10)
        self.sp_grado.setValue(2)
        self.sp_grado.setDecimals(0)
        grado_h.addWidget(self.sp_grado)
        gm.addLayout(grado_h)
        ll.addWidget(grp_met)

        # SymPy
        grp_sym = QGroupBox("Polinomio simbólico (SymPy)")
        grp_sym.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Preferred)
        gs = QVBoxLayout(grp_sym)
        self.lbl_poly = QLabel("—")
        self.lbl_poly.setWordWrap(True)
        self.lbl_poly.setSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Preferred)
        self.lbl_poly.setStyleSheet(
            "color: #43e97b; font-style: italic; font-size: 10px;"
        )
        gs.addWidget(self.lbl_poly)
        btn_sym = QPushButton("🔣  Generar polinomio con SymPy")
        btn_sym.setMinimumHeight(36)
        btn_sym.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        btn_sym.clicked.connect(self._generar_polinomio_simbolico)
        gs.addWidget(btn_sym)
        ll.addWidget(grp_sym)

        # Botones
        btn_calc = QPushButton("▶  Interpolar")
        btn_calc.setMinimumHeight(36)
        btn_calc.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        btn_calc.clicked.connect(self._calcular)

        btn_limpiar = QPushButton("🗑  Limpiar")
        btn_limpiar.setMinimumHeight(36)
        btn_limpiar.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        btn_limpiar.clicked.connect(self._limpiar)

        bh = QHBoxLayout()
        bh.addWidget(btn_calc)
        bh.addWidget(btn_limpiar)
        ll.addLayout(bh)

        lbl_res = QLabel("Resultado:")
        lbl_res.setWordWrap(True)
        lbl_res.setSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Fixed)
        ll.addWidget(lbl_res)

        self.txt_result = QTextEdit()
        self.txt_result.setReadOnly(True)
        self.txt_result.setFont(QFont("Courier New", 9))
        self.txt_result.setMinimumHeight(120)
        ll.addWidget(self.txt_result)
        ll.addStretch()

        scroll.setWidget(left_inner)
        splitter.addWidget(scroll)

        # ── Panel derecho ─────────────────────────────────────────────────────
        right = QWidget()
        rl = QVBoxLayout(right)

        lbl_tabla = QLabel("Tabla comparativa:")
        lbl_tabla.setWordWrap(True)
        lbl_tabla.setSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Fixed)
        rl.addWidget(lbl_tabla)

        self.tabla = QTableWidget(0, 3)
        self.tabla.setHorizontalHeaderLabels(
            ["Método", "y estimado", "Error vs Lagrange"]
        )
        self.tabla.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        self.tabla.setMinimumHeight(160)
        rl.addWidget(self.tabla)

        if MATPLOTLIB_OK:
            self.fig = Figure(figsize=(6, 4))
            self.canvas = FigureCanvas(self.fig)
            self.toolbar = NavigationToolbar(self.canvas, right)
            rl.addWidget(self.toolbar)
            rl.addWidget(self.canvas)

        splitter.addWidget(right)
        splitter.setStretchFactor(0, 1)
        splitter.setStretchFactor(1, 2)
        root.addWidget(splitter)

    # ── SymPy ──────────────────────────────────────────────────────────────────

    def _generar_polinomio_simbolico(self):
        try:
            xs, ys = self._parse_datos()
            res = diferencias_divididas(xs, ys)
            coef = res["coeficientes"]
            x_sym = sp.Symbol("x")
            poly = sp.Integer(0)
            term = sp.Integer(1)
            for i, c in enumerate(coef):
                poly += sp.Rational(c).limit_denominator(10000) * term
                if i < len(xs) - 1:
                    term *= (x_sym - sp.Rational(xs[i]).limit_denominator(10000))
            poly_expand = sp.expand(poly)
            self.lbl_poly.setText(f"P(x) = {poly_expand}")
        except Exception as e:
            self.lbl_poly.setText(f"⚠ {e}")

    # ── Parseo ─────────────────────────────────────────────────────────────────

    def _parse_datos(self):
        xs = np.array([float(v.strip()) for v in self.le_x.text().split(",")])
        ys = np.array([float(v.strip()) for v in self.le_y.text().split(",")])
        if len(xs) != len(ys):
            raise ValueError("x e y deben tener la misma cantidad de valores.")
        return xs, ys

    def _parse_xeval(self):
        raw = self.le_xeval.text().strip()
        if "," in raw:
            return np.array([float(v.strip()) for v in raw.split(",")])
        return float(raw)

    # ── Cálculo ────────────────────────────────────────────────────────────────

    def _calcular(self):
        try:
            xs, ys = self._parse_datos()
            self._last_xs, self._last_ys = xs, ys
            x_eval = self._parse_xeval()
            metodo = self.cb_metodo.currentText()
            resultados = {}

            if "Lagrange" in metodo or "Todos" in metodo:
                res = lagrange(xs, ys, x_eval)
                resultados["Lagrange"] = float(
                    np.atleast_1d(res["y_interpolado"])[0]
                )

            if "Newton" in metodo or "Todos" in metodo:
                res = newton_interpolacion(xs, ys, x_eval)
                resultados["Newton DD"] = float(
                    np.atleast_1d(res["y_interpolado"])[0]
                )

            if "Spline" in metodo or "Todos" in metodo:
                cs = CubicSpline(xs, ys)
                resultados["Spline Cúbico"] = float(np.atleast_1d(cs(x_eval))[0])

            if "Mínimos" in metodo or "Todos" in metodo:
                grado = int(self.sp_grado.value())
                coefs = np.polyfit(xs, ys, grado)
                p = np.poly1d(coefs)
                resultados[f"MC Grado {grado}"] = float(
                    np.atleast_1d(p(x_eval))[0]
                )

            ref = list(resultados.values())[0]
            lines = [f"  x evaluado = {x_eval}", ""]
            for met, val in resultados.items():
                err = abs(val - ref) if len(resultados) > 1 else 0.0
                lines.append(
                    f"  {met:<22} y = {val:.10f}  Δ = {err:.2e}"
                )
            self.txt_result.setPlainText("\n".join(lines))

            self.tabla.setRowCount(0)
            for met, val in resultados.items():
                r = self.tabla.rowCount()
                self.tabla.insertRow(r)
                err = abs(val - ref) if len(resultados) > 1 else 0.0
                self.tabla.setItem(r, 0, QTableWidgetItem(met))
                self.tabla.setItem(r, 1, QTableWidgetItem(f"{val:.10f}"))
                self.tabla.setItem(r, 2, QTableWidgetItem(f"{err:.2e}"))

            self._graficar(xs, ys, x_eval, resultados)

            if self._historial_fn:
                self._historial_fn(
                    "Interpolación", metodo,
                    f"y({x_eval}) ≈ {ref:.8f}"
                )

        except Exception:
            self.txt_result.setPlainText(f"⚠ Error:\n{traceback.format_exc()}")

    # ── Gráfica ────────────────────────────────────────────────────────────────

    def _graficar(self, xs, ys, x_eval, resultados: dict):
        if not MATPLOTLIB_OK:
            return
        t = get_theme()
        self.fig.clear()
        self.fig.patch.set_facecolor(t["plot_bg"])
        ax = self.fig.add_subplot(111)
        ax.set_facecolor(t["plot_bg"])

        x_fine = np.linspace(xs[0], xs[-1], 500)

        try:
            res = newton_interpolacion(xs, ys, x_fine)
            ax.plot(x_fine, res["y_interpolado"], color=t["accent"],
                    linewidth=2, label="Newton DD", zorder=3)
        except Exception:
            pass

        try:
            cs = CubicSpline(xs, ys)
            ax.plot(x_fine, cs(x_fine), color=t["accent2"], linewidth=1.5,
                    linestyle="--", label="Spline Cúbico", zorder=3)
        except Exception:
            pass

        ax.scatter(xs, ys, color=t["accent3"], s=60, zorder=5, label="Nodos")

        x_e = float(np.atleast_1d(x_eval)[0])
        for val in list(resultados.values())[:1]:
            ax.scatter([x_e], [val], marker="*", s=150, zorder=6, color=t["accent2"])

        ax.set_xlabel("x", color=t["plot_fg"])
        ax.set_ylabel("y", color=t["plot_fg"])
        ax.set_title("Interpolación", color=t["plot_fg"], fontsize=10)
        ax.tick_params(colors=t["plot_fg"])
        for sp_ in ax.spines.values():
            sp_.set_edgecolor(t["border"])
        ax.grid(True, color=t["plot_grid"], alpha=0.4)
        ax.legend(fontsize=8, facecolor=t["bg_card"], labelcolor=t["text_primary"])
        self.fig.tight_layout()
        self.canvas.draw()

    def _limpiar(self):
        self.txt_result.clear()
        self.tabla.setRowCount(0)
        self.lbl_poly.setText("—")
        if MATPLOTLIB_OK:
            self.fig.clear()
            self.canvas.draw()

    def apply_theme(self):
        if MATPLOTLIB_OK and self._last_xs is not None:
            try:
                self._graficar(
                    self._last_xs, self._last_ys,
                    float(self.le_xeval.text()), {}
                )
            except Exception:
                pass
