# tabs/__init__.py
# Paquete de pestañas de la aplicación de Métodos Numéricos
