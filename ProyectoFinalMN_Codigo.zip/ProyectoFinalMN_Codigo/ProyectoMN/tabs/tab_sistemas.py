"""
PROYECTO FINAL — Métodos Numéricos
Tab: Módulo 3 — Sistemas de Ecuaciones Lineales

Métodos: Eliminación Gaussiana, Gauss-Jordan, Factorización LU,
         Jacobi, Gauss-Seidel
Backend: metodos.py (biblioteca central)
NumPy: numpy.linalg.solve como solución de referencia exacta
"""

import traceback
import numpy as np

from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QGridLayout,
    QPushButton, QLabel, QLineEdit, QComboBox,
    QGroupBox, QSplitter, QTableWidget, QTableWidgetItem,
    QTextEdit, QHeaderView, QSpinBox,
    QScrollArea, QFrame, QSizePolicy,
)
from PyQt6.QtCore import Qt
from PyQt6.QtGui import QFont

try:
    import matplotlib
    matplotlib.use("QtAgg")
    from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg as FigureCanvas
    from matplotlib.backends.backend_qtagg import NavigationToolbar2QT as NavigationToolbar
    from matplotlib.figure import Figure
    MATPLOTLIB_OK = True
except Exception:
    MATPLOTLIB_OK = False

from metodos import gauss_eliminacion, gauss_jordan, factorizacion_lu, jacobi, gauss_seidel
from themes import get_theme


class TabSistemas(QWidget):
    """
    Pestaña de Sistemas de Ecuaciones Lineales — Módulo 3.
    Implementa: Gauss, Gauss-Jordan, LU, Jacobi, Gauss-Seidel.
    Matriz dinámica de 2×2 hasta 8×8 con QSpinBox.
    """

    def __init__(self, historial_fn=None, parent=None):
        super().__init__(parent)
        self._historial_fn = historial_fn
        self._n = 3
        self._celdas_A: list[list[QLineEdit]] = []
        self._celdas_b: list[QLineEdit] = []
        self._init_ui()
        self._rebuild_matrix()

    def _init_ui(self):
        root = QHBoxLayout(self)
        root.setContentsMargins(4, 4, 4, 4)

        splitter = QSplitter(Qt.Orientation.Horizontal)

        # ── Panel izquierdo (scroll) ──────────────────────────────────────────
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(scroll.Shape.NoFrame)
        scroll.setSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Expanding)

        left_inner = QWidget()
        ll = QVBoxLayout(left_inner)
        ll.setSpacing(10)
        ll.setContentsMargins(8, 8, 8, 8)

        # Tamaño
        grp_sz = QGroupBox("Dimensión del sistema")
        grp_sz.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Preferred)
        gh = QHBoxLayout(grp_sz)
        lbl_n = QLabel("n =")
        lbl_n.setSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Fixed)
        gh.addWidget(lbl_n)
        self.sp_n = QSpinBox()
        self.sp_n.setMinimumHeight(34)
        self.sp_n.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        self.sp_n.setRange(2, 8)
        self.sp_n.setValue(3)
        self.sp_n.valueChanged.connect(self._rebuild_matrix)
        gh.addWidget(self.sp_n)
        btn_ej = QPushButton("Cargar ejemplo")
        btn_ej.setMinimumHeight(34)
        btn_ej.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        btn_ej.clicked.connect(self._cargar_ejemplo)
        gh.addWidget(btn_ej)
        ll.addWidget(grp_sz)

        # Matriz con QScrollArea
        grp_mat = QGroupBox("Matriz A  |  vector b")
        grp_mat.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Preferred)
        grp_mat_layout = QVBoxLayout(grp_mat)
        grp_mat_layout.setContentsMargins(4, 4, 4, 4)

        self.scroll_mat = QScrollArea()
        self.scroll_mat.setWidgetResizable(True)
        self.scroll_mat.setFrameShape(QFrame.Shape.NoFrame)
        self.scroll_mat.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Preferred)
        self.scroll_mat.setMinimumHeight(100)

        self.mat_container = QWidget()
        self.mat_layout = QGridLayout(self.mat_container)
        self.scroll_mat.setWidget(self.mat_container)
        grp_mat_layout.addWidget(self.scroll_mat)
        ll.addWidget(grp_mat)

        # Parámetros iterativos
        grp_it = QGroupBox("Parámetros iterativos")
        grp_it.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Preferred)
        gi = QGridLayout(grp_it)
        gi.setColumnStretch(0, 0)
        gi.setColumnStretch(1, 1)
        gi.setVerticalSpacing(8)

        lbl_tol = QLabel("Tolerancia:")
        lbl_tol.setWordWrap(True)
        lbl_tol.setSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Fixed)
        gi.addWidget(lbl_tol, 0, 0)
        self.le_tol = QLineEdit("1e-8")
        self.le_tol.setMinimumHeight(34)
        self.le_tol.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        self.le_tol.setPlaceholderText("ej: 1e-8")
        gi.addWidget(self.le_tol, 0, 1)

        lbl_iter = QLabel("Máx iteraciones:")
        lbl_iter.setWordWrap(True)
        lbl_iter.setSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Fixed)
        gi.addWidget(lbl_iter, 1, 0)
        self.le_iter = QLineEdit("200")
        self.le_iter.setMinimumHeight(34)
        self.le_iter.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        gi.addWidget(self.le_iter, 1, 1)
        ll.addWidget(grp_it)

        # Método
        grp_met = QGroupBox("Método")
        grp_met.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Preferred)
        gm = QVBoxLayout(grp_met)
        self.cb_metodo = QComboBox()
        self.cb_metodo.setMinimumHeight(34)
        self.cb_metodo.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        self.cb_metodo.addItems([
            "Eliminación Gaussiana",
            "Gauss-Jordan",
            "Factorización LU",
            "Jacobi",
            "Gauss-Seidel",
            "Todos (comparación)",
        ])
        gm.addWidget(self.cb_metodo)
        ll.addWidget(grp_met)

        # Botones
        btn_calc = QPushButton("▶  Resolver")
        btn_calc.setMinimumHeight(36)
        btn_calc.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        btn_calc.clicked.connect(self._calcular)

        btn_limpiar = QPushButton("🗑  Limpiar")
        btn_limpiar.setMinimumHeight(36)
        btn_limpiar.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        btn_limpiar.clicked.connect(self._limpiar)

        bh = QHBoxLayout()
        bh.addWidget(btn_calc)
        bh.addWidget(btn_limpiar)
        ll.addLayout(bh)

        lbl_res = QLabel("Resultado:")
        lbl_res.setWordWrap(True)
        lbl_res.setSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Fixed)
        ll.addWidget(lbl_res)

        self.txt_result = QTextEdit()
        self.txt_result.setReadOnly(True)
        self.txt_result.setFont(QFont("Courier New", 9))
        self.txt_result.setMinimumHeight(130)
        ll.addWidget(self.txt_result)
        ll.addStretch()

        scroll.setWidget(left_inner)
        splitter.addWidget(scroll)

        # ── Panel derecho ─────────────────────────────────────────────────────
        right = QWidget()
        rl = QVBoxLayout(right)

        lbl_comp = QLabel("Comparativa:")
        lbl_comp.setWordWrap(True)
        lbl_comp.setSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Fixed)
        rl.addWidget(lbl_comp)

        self.tabla = QTableWidget(0, 4)
        self.tabla.setHorizontalHeaderLabels(
            ["Método", "Solución", "Residuo ‖Ax-b‖", "Conv."]
        )
        self.tabla.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        self.tabla.setMinimumHeight(160)
        rl.addWidget(self.tabla)

        if MATPLOTLIB_OK:
            self.fig = Figure(figsize=(6, 4))
            self.canvas = FigureCanvas(self.fig)
            self.toolbar = NavigationToolbar(self.canvas, right)
            rl.addWidget(self.toolbar)
            rl.addWidget(self.canvas)

        splitter.addWidget(right)
        splitter.setStretchFactor(0, 1)
        splitter.setStretchFactor(1, 2)
        root.addWidget(splitter)

    # ── Matriz dinámica ───────────────────────────────────────────────────────

    def _rebuild_matrix(self, n=None):
        if n is None:
            n = self.sp_n.value()
        self._n = n
        t = get_theme()

        while self.mat_layout.count():
            item = self.mat_layout.takeAt(0)
            if item.widget():
                item.widget().deleteLater()

        self._celdas_A = [[None] * n for _ in range(n)]
        self._celdas_b = [None] * n

        cell_style = f"""
            QLineEdit {{
                background-color: {t['bg_card']};
                color: {t['text_primary']};
                border: 1.5px solid {t['border']};
                border-radius: 4px;
                padding: 4px;
                font-size: 12px;
                font-weight: bold;
            }}
            QLineEdit:focus {{
                border: 1.5px solid {t['accent']};
                background-color: {t['hover']};
            }}
        """
        b_style = f"""
            QLineEdit {{
                background-color: {t['bg_card']};
                color: {t['accent2']};
                border: 1.5px solid {t['accent2']};
                border-radius: 4px;
                padding: 4px;
                font-size: 12px;
                font-weight: bold;
            }}
            QLineEdit:focus {{
                border: 1.5px solid {t['accent']};
            }}
        """

        for j in range(n):
            lbl = QLabel(f"x{j + 1}")
            lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
            lbl.setStyleSheet(
                f"color: {t['accent']}; font-weight: bold; font-size: 11px;"
            )
            self.mat_layout.addWidget(lbl, 0, j)

        lbl_b = QLabel("b")
        lbl_b.setAlignment(Qt.AlignmentFlag.AlignCenter)
        lbl_b.setStyleSheet(
            f"color: {t['accent2']}; font-weight: bold; font-size: 11px;"
        )
        self.mat_layout.addWidget(lbl_b, 0, n + 1)

        for i in range(n):
            lbl_row = QLabel(f"F{i + 1}")
            lbl_row.setAlignment(Qt.AlignmentFlag.AlignCenter)
            lbl_row.setStyleSheet(
                f"color: {t['text_secondary']}; font-size: 10px;"
            )
            self.mat_layout.addWidget(lbl_row, i + 1, n + 2)

            for j in range(n):
                le = QLineEdit("0")
                le.setMinimumSize(55, 34)
                le.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
                le.setAlignment(Qt.AlignmentFlag.AlignCenter)
                le.setStyleSheet(cell_style)
                self.mat_layout.addWidget(le, i + 1, j)
                self._celdas_A[i][j] = le

            sep = QLabel("│")
            sep.setAlignment(Qt.AlignmentFlag.AlignCenter)
            sep.setStyleSheet(
                f"color: {t['accent']}; font-size: 18px; font-weight: bold;"
            )
            self.mat_layout.addWidget(sep, i + 1, n)

            le_b = QLineEdit("0")
            le_b.setMinimumSize(55, 34)
            le_b.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
            le_b.setAlignment(Qt.AlignmentFlag.AlignCenter)
            le_b.setStyleSheet(b_style)
            self.mat_layout.addWidget(le_b, i + 1, n + 1)
            self._celdas_b[i] = le_b

        for j in range(n + 3):
            self.mat_layout.setColumnStretch(j, 1)
        self.mat_layout.setSpacing(5)
        self.mat_layout.setContentsMargins(8, 8, 8, 8)

    def _cargar_ejemplo(self):
        A_ej = [[4, 1, -1], [2, 7, 1], [1, -3, 12]]
        b_ej = [3, 19, -7]
        self.sp_n.setValue(3)
        self._rebuild_matrix(3)
        for i in range(3):
            for j in range(3):
                self._celdas_A[i][j].setText(str(A_ej[i][j]))
            self._celdas_b[i].setText(str(b_ej[i]))

    def _leer_Ab(self):
        n = self._n
        A = np.zeros((n, n))
        b = np.zeros(n)
        for i in range(n):
            for j in range(n):
                A[i, j] = float(self._celdas_A[i][j].text())
            b[i] = float(self._celdas_b[i].text())
        return A, b

    # ── Cálculo ────────────────────────────────────────────────────────────────

    def _calcular(self):
        try:
            A, b = self._leer_Ab()
            tol = float(self.le_tol.text())
            max_it = int(self.le_iter.text())
            metodo = self.cb_metodo.currentText()

            if np.allclose(A, 0):
                self.txt_result.setPlainText(
                    "⚠ La matriz A está vacía o es todo ceros.\n"
                    "Ingresa los coeficientes o usa 'Cargar ejemplo'."
                )
                return

            det = np.linalg.det(A)
            if abs(det) < 1e-12:
                self.txt_result.setPlainText(
                    f"⚠ La matriz es singular (det ≈ {det:.2e}).\n"
                    "El sistema no tiene solución única."
                )
                return

            sol_ref = np.linalg.solve(A, b)
            resultados = {}

            if "Gaussiana" in metodo or "Todos" in metodo:
                res = gauss_eliminacion(A, b)
                resultados["Gauss Elim."] = (res["solucion"], res["residuo"], True)

            if "Jordan" in metodo or "Todos" in metodo:
                res = gauss_jordan(A, b)
                resultados["Gauss-Jordan"] = (res["solucion"], res["residuo"], True)

            if "LU" in metodo or "Todos" in metodo:
                res = factorizacion_lu(A, b)
                resultados["LU"] = (res["solucion"], res["residuo"], True)

            if "Jacobi" in metodo or "Todos" in metodo:
                res = jacobi(A, b, tol=tol, max_iter=max_it)
                resultados["Jacobi"] = (
                    res["solucion"], res["residuo"], res["convergencia"]
                )

            if "Gauss-Seidel" in metodo or "Todos" in metodo:
                res = gauss_seidel(A, b, tol=tol, max_iter=max_it)
                resultados["Gauss-Seidel"] = (
                    res["solucion"], res["residuo"], res["convergencia"]
                )

            lines = [
                f"  Solución exacta (numpy): {np.round(sol_ref, 8)}", ""
            ]
            for met, (x, res_, conv) in resultados.items():
                err_vs_exact = np.linalg.norm(x - sol_ref)
                lines.append(
                    f"  {met:<22} x = {np.round(x, 6)}  "
                    f"residuo = {res_:.2e}  Δexact = {err_vs_exact:.2e}"
                )
            self.txt_result.setPlainText("\n".join(lines))

            self.tabla.setRowCount(0)
            for met, (x, res_, conv) in resultados.items():
                r = self.tabla.rowCount()
                self.tabla.insertRow(r)
                self.tabla.setItem(r, 0, QTableWidgetItem(met))
                self.tabla.setItem(r, 1, QTableWidgetItem(str(np.round(x, 4))))
                self.tabla.setItem(r, 2, QTableWidgetItem(f"{res_:.2e}"))
                self.tabla.setItem(r, 3, QTableWidgetItem("✅" if conv else "⚠"))

            self._graficar_residuos(resultados)

            if self._historial_fn:
                self._historial_fn(
                    "Sistemas", metodo,
                    f"sol ≈ {np.round(sol_ref, 4)}"
                )

        except Exception:
            self.txt_result.setPlainText(f"⚠ Error:\n{traceback.format_exc()}")

    # ── Gráfica ────────────────────────────────────────────────────────────────

    def _graficar_residuos(self, resultados: dict):
        if not MATPLOTLIB_OK:
            return
        t = get_theme()
        self.fig.clear()
        self.fig.patch.set_facecolor(t["plot_bg"])
        ax = self.fig.add_subplot(111)
        ax.set_facecolor(t["plot_bg"])

        nombres = list(resultados.keys())
        residuos = [resultados[m][1] for m in nombres]
        colors = [t["accent"], t["accent2"], t["accent3"], "#f39c12", "#9b59b6"]

        ax.bar(
            nombres, residuos,
            color=[colors[i % len(colors)] for i in range(len(nombres))],
            edgecolor=t["border"],
        )
        ax.set_yscale("log")
        ax.set_ylabel("Residuo ‖Ax - b‖", color=t["plot_fg"])
        ax.set_title("Comparación de residuos por método", color=t["plot_fg"], fontsize=10)
        ax.tick_params(colors=t["plot_fg"])
        ax.tick_params(axis="x", rotation=20)
        for sp_ in ax.spines.values():
            sp_.set_edgecolor(t["border"])
        ax.grid(True, color=t["plot_grid"], alpha=0.4, axis="y")
        self.fig.tight_layout()
        self.canvas.draw()

    def _limpiar(self):
        self.txt_result.clear()
        self.tabla.setRowCount(0)
        if MATPLOTLIB_OK:
            self.fig.clear()
            self.canvas.draw()

    def apply_theme(self):
        self._rebuild_matrix(self._n)
