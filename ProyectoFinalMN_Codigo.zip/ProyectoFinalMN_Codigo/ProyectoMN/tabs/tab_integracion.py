"""
PROYECTO FINAL — Métodos Numéricos
Tab: Módulo 4 — Derivación e Integración Numérica

Métodos Integración: Trapecio, Simpson 1/3, Simpson 3/8, Gauss-Legendre
Métodos Derivación: Adelante, Atrás, Centrada, Segunda, Orden 4
Backend: metodos.py (biblioteca central)
SciPy: scipy.integrate.quad como referencia exacta
SymPy: derivada simbólica exacta para validación
"""

import traceback
import numpy as np
import sympy as sp
from scipy import integrate

from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QGridLayout,
    QLabel, QLineEdit, QPushButton, QComboBox,
    QGroupBox, QTextEdit, QTableWidget, QTableWidgetItem,
    QHeaderView, QSplitter, QSizePolicy, QScrollArea,
)
from PyQt6.QtCore import Qt
from PyQt6.QtGui import QFont

try:
    import matplotlib
    matplotlib.use("QtAgg")
    from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg as FigureCanvas
    from matplotlib.backends.backend_qtagg import NavigationToolbar2QT as NavigationToolbar
    from matplotlib.figure import Figure
    MATPLOTLIB_OK = True
except Exception:
    MATPLOTLIB_OK = False

from metodos import (
    trapecio, simpson_13, simpson_38, gauss_legendre,
    derivada_adelante, derivada_atras, derivada_centrada,
    segunda_derivada, derivada_orden4,
)
from themes import get_theme
from utils import make_f


class TabIntegracion(QWidget):
    """
    Pestaña de Integración Numérica y Derivadas — Módulo 4.
    Integración: Trapecio, Simpson 1/3, Simpson 3/8, Gauss-Legendre, quad.
    Derivación: Adelante, Atrás, Centrada, Segunda, Orden 4.
    """

    def __init__(self, historial_fn=None, parent=None):
        super().__init__(parent)
        self._historial_fn = historial_fn
        self._fig_cache = None
        self._build_ui()

    def _build_ui(self):
        root = QHBoxLayout(self)
        root.setContentsMargins(4, 4, 4, 4)

        splitter = QSplitter(Qt.Orientation.Horizontal)

        # ── Panel izquierdo (scroll) ──────────────────────────────────────────
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(scroll.Shape.NoFrame)
        scroll.setSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Expanding)

        left_inner = QWidget()
        ll = QVBoxLayout(left_inner)
        ll.setSpacing(10)
        ll.setContentsMargins(8, 8, 8, 8)

        # Función
        grp_fn = QGroupBox("Función f(x)")
        grp_fn.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Preferred)
        gf = QGridLayout(grp_fn)
        gf.setColumnStretch(0, 0)
        gf.setColumnStretch(1, 1)
        gf.setVerticalSpacing(8)

        params_fn = [
            ("f(x) =",              "le_func", "x**2 * sin(x)",   "ej: x**2 * sin(x)"),
            ("a =",                 "le_a",    "0",               "límite inferior"),
            ("b =",                 "le_b",    "3.14159265",      "límite superior (pi ≈ 3.14159265)"),
            ("n (subintervalos) =", "le_n",    "100",             "número entero ≥ 2"),
        ]
        for row, (lbl_txt, attr, val, ph) in enumerate(params_fn):
            lbl = QLabel(lbl_txt)
            lbl.setWordWrap(True)
            lbl.setSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Fixed)
            gf.addWidget(lbl, row, 0)
            le = QLineEdit(val)
            le.setMinimumHeight(34)
            le.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
            le.setPlaceholderText(ph)
            gf.addWidget(le, row, 1)
            setattr(self, attr, le)
        ll.addWidget(grp_fn)

        # Método integración
        grp_int = QGroupBox("Método de Integración")
        grp_int.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Preferred)
        gi = QVBoxLayout(grp_int)
        self.cb_metodo = QComboBox()
        self.cb_metodo.setMinimumHeight(34)
        self.cb_metodo.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        self.cb_metodo.addItems([
            "Trapecio compuesto",
            "Simpson 1/3 compuesto",
            "Simpson 3/8 compuesto",
            "Gauss-Legendre",
            "Todos + SciPy quad (comparación)",
        ])
        gi.addWidget(self.cb_metodo)
        ll.addWidget(grp_int)

        # Derivadas
        grp_der = QGroupBox("Derivadas numéricas vs SymPy")
        grp_der.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Preferred)
        gd = QGridLayout(grp_der)
        gd.setColumnStretch(0, 0)
        gd.setColumnStretch(1, 1)
        gd.setVerticalSpacing(8)

        params_der = [
            ("Punto x₀ =", "le_x0", "1.0",     "punto donde calcular f'(x)"),
            ("Paso h =",   "le_h",  "0.00001", "tamaño de paso"),
        ]
        for row, (lbl_txt, attr, val, ph) in enumerate(params_der):
            lbl = QLabel(lbl_txt)
            lbl.setWordWrap(True)
            lbl.setSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Fixed)
            gd.addWidget(lbl, row, 0)
            le = QLineEdit(val)
            le.setMinimumHeight(34)
            le.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
            le.setPlaceholderText(ph)
            gd.addWidget(le, row, 1)
            setattr(self, attr, le)
        ll.addWidget(grp_der)

        # Botones
        btn_int = QPushButton("▶  Calcular Integral")
        btn_int.setMinimumHeight(36)
        btn_int.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        btn_int.clicked.connect(self._calcular_integral)

        btn_der = QPushButton("▶  Calcular Derivadas")
        btn_der.setMinimumHeight(36)
        btn_der.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        btn_der.clicked.connect(self._calcular_derivadas)

        btn_graf = QPushButton("📊  Graficar")
        btn_graf.setMinimumHeight(36)
        btn_graf.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        btn_graf.clicked.connect(self._graficar)

        bh = QHBoxLayout()
        bh.addWidget(btn_int)
        bh.addWidget(btn_der)
        bh.addWidget(btn_graf)
        ll.addLayout(bh)

        lbl_res = QLabel("Resultados:")
        lbl_res.setWordWrap(True)
        lbl_res.setSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Fixed)
        ll.addWidget(lbl_res)

        self.txt_result = QTextEdit()
        self.txt_result.setReadOnly(True)
        self.txt_result.setFont(QFont("Courier New", 9))
        self.txt_result.setMinimumHeight(150)
        ll.addWidget(self.txt_result)
        ll.addStretch()

        scroll.setWidget(left_inner)
        splitter.addWidget(scroll)

        # ── Panel derecho ─────────────────────────────────────────────────────
        right = QWidget()
        rl = QVBoxLayout(right)

        lbl_tabla = QLabel("Tabla comparativa:")
        lbl_tabla.setWordWrap(True)
        lbl_tabla.setSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Fixed)
        rl.addWidget(lbl_tabla)

        self.tabla = QTableWidget(0, 4)
        self.tabla.setHorizontalHeaderLabels(
            ["Método", "Resultado", "Error vs quad", "Orden"]
        )
        self.tabla.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        self.tabla.setMinimumHeight(160)
        rl.addWidget(self.tabla)

        if MATPLOTLIB_OK:
            self.fig = Figure(figsize=(6, 5))
            self.canvas = FigureCanvas(self.fig)
            self.toolbar = NavigationToolbar(self.canvas, right)
            rl.addWidget(self.toolbar)
            rl.addWidget(self.canvas)
        else:
            rl.addWidget(QLabel("⚠ Matplotlib no disponible"))

        splitter.addWidget(right)
        splitter.setStretchFactor(0, 1)
        splitter.setStretchFactor(1, 2)
        root.addWidget(splitter)

    # ── Helpers ───────────────────────────────────────────────────────────────

    def _get_f(self):
        return make_f(self.le_func.text())

    def _get_params(self):
        a = float(self.le_a.text())
        b = float(self.le_b.text())
        n = int(self.le_n.text())
        x0 = float(self.le_x0.text())
        h = float(self.le_h.text())
        return a, b, n, x0, h

    # ── Integración ───────────────────────────────────────────────────────────

    def _calcular_integral(self):
        try:
            f = self._get_f()
            a, b, n, x0, h = self._get_params()
            idx = self.cb_metodo.currentIndex()

            ordenes = {
                "Trapecio":       "O(h²)",
                "Simpson 1/3":    "O(h⁴)",
                "Simpson 3/8":    "O(h⁴)",
                "Gauss-Legendre": "O(h²ⁿ)",
                "SciPy quad":     "adaptativo",
            }

            quad_val, quad_err = integrate.quad(f, a, b)

            metodos_calc = [
                ("Trapecio",       lambda: trapecio(f, a, b, n)["integral"]),
                ("Simpson 1/3",    lambda: simpson_13(f, a, b, n)["integral"]),
                ("Simpson 3/8",    lambda: simpson_38(f, a, b, n)["integral"]),
                ("Gauss-Legendre", lambda: gauss_legendre(f, a, b, n=min(n, 20))["integral"]),
                ("SciPy quad",     lambda: quad_val),
            ]

            if idx < 4:
                nom, fn = metodos_calc[idx]
                val = fn()
                resultados = [(nom, val)]
            else:
                resultados = [(nom, fn()) for nom, fn in metodos_calc]

            self.tabla.setRowCount(0)
            for nom, val in resultados:
                r = self.tabla.rowCount()
                self.tabla.insertRow(r)
                err = abs(val - quad_val)
                self.tabla.setItem(r, 0, QTableWidgetItem(nom))
                self.tabla.setItem(r, 1, QTableWidgetItem(f"{val:.12f}"))
                self.tabla.setItem(r, 2, QTableWidgetItem(f"{err:.2e}"))
                self.tabla.setItem(r, 3, QTableWidgetItem(ordenes.get(nom, "—")))

            lines = [
                f"  f(x) = {self.le_func.text()}",
                f"  ∫ de {a} a {b},  n = {n}",
                f"  SciPy quad (referencia) = {quad_val:.14f}  (err est. {quad_err:.2e})",
                "",
            ]
            for nom, val in resultados:
                lines.append(
                    f"  {nom:<22} = {val:.12f}  Δquad = {abs(val - quad_val):.2e}"
                )
            self.txt_result.setPlainText("\n".join(lines))

            if self._historial_fn:
                self._historial_fn(
                    "Integración", self.cb_metodo.currentText(),
                    f"∫ = {resultados[0][1]:.8f}"
                )
        except Exception:
            self.txt_result.setPlainText(f"⚠ Error:\n{traceback.format_exc()}")

    # ── Derivadas ─────────────────────────────────────────────────────────────

    def _calcular_derivadas(self):
        try:
            f = self._get_f()
            _, _, _, x0, h = self._get_params()

            d_ad = derivada_adelante(f, x0, h)
            d_at = derivada_atras(f, x0, h)
            d_ce = derivada_centrada(f, x0, h)
            d_2a = segunda_derivada(f, x0, h)
            d_o4 = derivada_orden4(f, x0, h)

            try:
                x_sym = sp.Symbol("x")
                expr = sp.sympify(self.le_func.text())
                deriv1 = sp.diff(expr, x_sym)
                deriv2 = sp.diff(deriv1, x_sym)
                d1_exact = float(deriv1.subs(x_sym, x0).evalf())
                d2_exact = float(deriv2.subs(x_sym, x0).evalf())
                sym_str = (
                    f"  f'(x₀) (SymPy exacto) = {d1_exact:.12f}\n"
                    f"  f''(x₀)(SymPy exacto) = {d2_exact:.12f}\n"
                    f"  Error adelante  vs SymPy = {abs(d_ad - d1_exact):.2e}\n"
                    f"  Error centrada  vs SymPy = {abs(d_ce - d1_exact):.2e}\n"
                    f"  Error orden4    vs SymPy = {abs(d_o4 - d1_exact):.2e}"
                )
            except Exception as se:
                sym_str = f"  (SymPy no pudo calcular: {se})"

            lines = [
                f"  f(x) = {self.le_func.text()}   en x₀ = {x0}   h = {h}",
                "",
                f"  Diferencia adelante  O(h)  : f'(x₀) = {d_ad:.12f}",
                f"  Diferencia atrás     O(h)  : f'(x₀) = {d_at:.12f}",
                f"  Diferencia centrada  O(h²) : f'(x₀) = {d_ce:.12f}",
                f"  Cinco puntos         O(h⁴) : f'(x₀) = {d_o4:.12f}",
                f"  Segunda derivada     O(h²) : f''(x₀) = {d_2a:.12f}",
                "",
                "  ── Comparación con SymPy ──",
                sym_str,
            ]
            self.txt_result.setPlainText("\n".join(lines))

        except Exception:
            self.txt_result.setPlainText(f"⚠ Error:\n{traceback.format_exc()}")

    # ── Gráfica ───────────────────────────────────────────────────────────────

    def _graficar(self):
        if not MATPLOTLIB_OK:
            return
        try:
            f = self._get_f()
            a, b, n, x0, h = self._get_params()
            t = get_theme()
            self.fig.clear()
            self.fig.patch.set_facecolor(t["plot_bg"])

            # Subplot superior: función + área (integración)
            ax1 = self.fig.add_subplot(211)
            # Subplot inferior: función + derivada
            ax2 = self.fig.add_subplot(212)

            for ax in (ax1, ax2):
                ax.set_facecolor(t["plot_bg"])
                ax.tick_params(colors=t["plot_fg"])
                for sp_ in ax.spines.values():
                    sp_.set_edgecolor(t["border"])
                ax.grid(True, color=t["plot_grid"], alpha=0.4)

            x = np.linspace(a, b, 500)
            y = f(x)

            ax1.plot(x, y, color=t["accent"], linewidth=2, label="f(x)")
            ax1.fill_between(x, 0, y, alpha=0.2, color=t["accent"], label="Área ∫f(x)dx")
            ax1.axhline(0, color=t["plot_fg"], linewidth=0.6, alpha=0.5)
            ax1.set_title(
                f"f(x) = {self.le_func.text()}",
                color=t["plot_fg"], fontsize=9
            )
            ax1.legend(fontsize=8, facecolor=t["bg_card"], labelcolor=t["text_primary"])

            dy = np.array([derivada_centrada(f, xi, h) for xi in x])
            ax2.plot(x, y,  color=t["accent"],  linewidth=1.5, label="f(x)")
            ax2.plot(x, dy, color=t["accent2"], linewidth=1.5,
                     linestyle="--", label="f'(x) centrada")
            ax2.axvline(x0, color=t["accent3"], linewidth=1,
                        linestyle=":", label=f"x₀={x0}")
            ax2.set_title("Función y su derivada numérica", color=t["plot_fg"], fontsize=9)
            ax2.legend(fontsize=8, facecolor=t["bg_card"], labelcolor=t["text_primary"])

            self.fig.tight_layout()
            self.canvas.draw()
            self._fig_cache = self.fig

        except Exception:
            self.txt_result.setPlainText(f"⚠ Error gráfica:\n{traceback.format_exc()}")

    def get_figure(self):
        return self._fig_cache if self._fig_cache else self.fig

    def apply_theme(self):
        if MATPLOTLIB_OK:
            try:
                self._graficar()
            except Exception:
                pass
